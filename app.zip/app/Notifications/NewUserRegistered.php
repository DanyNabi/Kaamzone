<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class NewUserRegistered extends Notification
{
    use Queueable;

    public function __construct(
        public $registeredUser
    ) {}

    public function via(object $notifiable): array
    {
        return ['mail', 'database'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('New User Registered')
            ->greeting('Hello Admin!')
            ->line('A new user has registered on your website.')
            ->line('Name: ' . $this->registeredUser->name)
            ->line('Email: ' . $this->registeredUser->email)
            ->action('View Users', url('/admin/users'))
            ->line('Please review the new registration.');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'new_user',
            'user_id' => $this->registeredUser->id,
            'name' => $this->registeredUser->name,
            'email' => $this->registeredUser->email,
            'message' => 'New user registered',
        ];
    }
}