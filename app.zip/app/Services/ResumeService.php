<?php

namespace App\Services;

use App\Models\Resume;
use App\Repositories\Interfaces\ResumeRepositoryInterface;

class ResumeService
{
    public function __construct(
        protected ResumeRepositoryInterface $repository
    ) {}

    public function getUserResumes($userId)
    {
        return $this->repository->all($userId);
    }

    public function create(array $data): Resume
    {
        return $this->repository->create($data);
    }

    public function update(Resume $resume, array $data): bool
    {
        return $this->repository->update($resume, $data);
    }

    public function delete(Resume $resume): bool
    {
        return $this->repository->delete($resume);
    }

    public function builder($id)
    {
        return $this->repository->findWithRelations($id);
    }
}
