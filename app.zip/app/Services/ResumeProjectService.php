<?php

namespace App\Services;

use App\Models\ResumeProject;
use App\Repositories\ResumeProjectRepository;

class ResumeProjectService
{
    public function __construct(
        protected ResumeProjectRepository $repository
    ) {}

    public function create(int $resumeId, array $data)
    {
        $data['resume_id'] = $resumeId;

        return $this->repository->create($data);
    }

    public function update(ResumeProject $project, array $data)
    {
        return $this->repository->update($project, $data);
    }

    public function delete(ResumeProject $project)
    {
        return $this->repository->delete($project);
    }
}