<?php

namespace App\Services;

use App\Repositories\Interfaces\ResumePersonalInfoRepositoryInterface;

class ResumePersonalInfoService
{
    protected $repository;

    public function __construct(
        ResumePersonalInfoRepositoryInterface $repository
    ) {
        $this->repository = $repository;
    }

    public function updateOrCreate(int $resumeId, array $data)
    {
        return $this->repository->updateOrCreate($resumeId, $data);
    }
}
