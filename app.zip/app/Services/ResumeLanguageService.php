<?php

namespace App\Services;

use App\Models\ResumeLanguage;
use App\Repositories\ResumeLanguageRepository;

class ResumeLanguageService
{
    public function __construct(
        protected ResumeLanguageRepository $repository
    ) {}

    public function create(int $resumeId, array $data)
    {
        $data['resume_id'] = $resumeId;

        return $this->repository->create($data);
    }

    public function update(ResumeLanguage $language, array $data)
    {
        return $this->repository->update($language, $data);
    }

    public function delete(ResumeLanguage $language)
    {
        return $this->repository->delete($language);
    }
}