<?php

namespace App\Services;

use App\Repositories\Interfaces\ResumeExperienceRepositoryInterface;

class ResumeExperienceService
{
    protected $repository;

    public function __construct(
        ResumeExperienceRepositoryInterface $repository
    ) {
        $this->repository = $repository;
    }

    public function create(int $resumeId, array $data)
    {
        return $this->repository->create($resumeId, $data);
    }

    public function update(int $id, array $data)
    {
        return $this->repository->update($id, $data);
    }

    public function delete(int $id)
    {
        return $this->repository->delete($id);
    }

    public function getResumeExperiences(int $resumeId)
    {
        return $this->repository->findByResume($resumeId);
    }

    public function find(int $id)
    {
        return $this->repository->findById($id);
    }
}
