<?php

namespace App\Services;

use App\Models\UserSubscription;
use App\Models\SubscriptionOrder;
use Illuminate\Support\Facades\DB;

class SubscriptionActivationService
{
    public static function activate(SubscriptionOrder $order)
    {
        DB::transaction(function () use ($order) {

            // Expire previous subscription
            UserSubscription::where('user_id', $order->user_id)
                ->where('module_id', $order->module_id)
                ->where('status', 'active')
                ->update([
                    'status' => 'expired',
                ]);

            // Create new subscription
            UserSubscription::create([

                'user_id' => $order->user_id,

                'module_id' => $order->module_id,

                'plan_id' => $order->plan_id,

                'starts_at' => now(),

                'expires_at' => now()->addDays($order->plan->duration),

                'status' => 'active',

            ]);

            // Update Order
            $order->update([

                'status' => 'completed',

                'payment_status' => 'paid',

                'paid_at' => now(),

            ]);

        });
    }
}