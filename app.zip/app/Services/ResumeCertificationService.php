<?php

namespace App\Services;

use App\Models\ResumeCertification;
use App\Repositories\ResumeCertificationRepository;

class ResumeCertificationService
{
    public function __construct(
        protected ResumeCertificationRepository $repository
    ) {}

    public function create(int $resumeId, array $data)
    {
        $data['resume_id'] = $resumeId;

        return $this->repository->create($data);
    }

    public function update(ResumeCertification $certification, array $data)
    {
        return $this->repository->update($certification, $data);
    }

    public function delete(ResumeCertification $certification)
    {
        return $this->repository->delete($certification);
    }
}