<?php

namespace App\Services;

use App\Repositories\Interfaces\ResumeEducationRepositoryInterface;

class ResumeEducationService
{
    public function __construct(
        protected ResumeEducationRepositoryInterface $repository
    ) {}

    public function create($resumeId, array $data)
    {
        $data['resume_id'] = $resumeId;

        return $this->repository->create($data);
    }

    public function update($id, array $data)
    {
        return $this->repository->update($id, $data);
    }

    public function delete($id)
    {
        return $this->repository->delete($id);
    }
}
