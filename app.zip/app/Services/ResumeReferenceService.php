<?php

namespace App\Services;

use App\Models\ResumeReference;
use App\Repositories\ResumeReferenceRepository;

class ResumeReferenceService
{
    public function __construct(
        protected ResumeReferenceRepository $repository
    ) {}

    public function create(int $resumeId, array $data)
    {
        $data['resume_id'] = $resumeId;

        return $this->repository->create($data);
    }

    public function update(ResumeReference $reference, array $data)
    {
        return $this->repository->update($reference, $data);
    }

    public function delete(ResumeReference $reference)
    {
        return $this->repository->delete($reference);
    }
}