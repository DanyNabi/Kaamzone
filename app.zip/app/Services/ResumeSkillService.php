<?php

namespace App\Services;

use App\Models\ResumeSkill;
use App\Repositories\ResumeSkillRepository;

class ResumeSkillService
{
    public function __construct(
        protected ResumeSkillRepository $repository
    ) {}

    public function create(int $resumeId, array $data)
    {
        $data['resume_id'] = $resumeId;

        return $this->repository->create($data);
    }

    public function update(ResumeSkill $skill, array $data)
    {
        return $this->repository->update($skill, $data);
    }

    public function delete(ResumeSkill $skill)
    {
        return $this->repository->delete($skill);
    }
}