<?php

namespace App\Services;

use App\Models\SubscriptionFeature;
use App\Models\SubscriptionModule;
use App\Models\SubscriptionPlanFeature;
use App\Models\User;

class SubscriptionService
{
    /**
     * Get user's active subscription
     */
    protected static function getSubscription(User $user, string $moduleSlug)
    {
        return $user->subscriptions()
            ->whereHas('module', function ($q) use ($moduleSlug) {
                $q->where('slug', $moduleSlug);
            })
            ->where('status', 'active')
            ->where(function ($q) {
                $q->whereNull('expires_at')
                    ->orWhere('expires_at', '>=', now());
            })
            ->with('plan')
            ->first();
    }

    /**
     * Get feature record
     */
    protected static function getFeature(string $moduleSlug, string $featureSlug)
    {
        $module = SubscriptionModule::where('slug', $moduleSlug)->first();

        if (!$module) {
            return null;
        }

        return SubscriptionFeature::where('module_id', $module->id)
            ->where('slug', $featureSlug)
            ->first();
    }

    /**
     * Get feature value
     */
    protected static function getPlanFeature($planId, $featureId)
    {
        return SubscriptionPlanFeature::where('plan_id', $planId)
            ->where('feature_id', $featureId)
            ->first();
    }

    /**
     * Return numeric/text limit
     */
    public static function getLimit(User $user, string $moduleSlug, string $featureSlug)
    {
        $subscription = self::getSubscription($user, $moduleSlug);

        if (!$subscription) {
            return null;
        }

        $feature = self::getFeature($moduleSlug, $featureSlug);

        if (!$feature) {
            return null;
        }

        $planFeature = self::getPlanFeature(
            $subscription->plan_id,
            $feature->id
        );

        if (!$planFeature) {
            return null;
        }

        if ($planFeature->is_unlimited) {
            return PHP_INT_MAX;
        }

        return $planFeature->value;
    }

    /**
     * Boolean feature
     */
    public static function hasFeature(User $user, string $moduleSlug, string $featureSlug)
    {
        return (bool) self::getLimit(
            $user,
            $moduleSlug,
            $featureSlug
        );
    }
}