<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobSeekerProfile extends Model
{
    protected $fillable = [

        'user_id',

        'profile_image',

        'resume',

        'bio',

        'skills',

        'experience',

        'education',

        'location'

    ];

    // USER

    public function user()
    {
        return $this->belongsTo(
            User::class
        );
    }
}
