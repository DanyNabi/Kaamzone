<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProviderProfile extends Model
{
    protected $fillable = [
        'user_id',
        'bio',
        'skills',
        'experience',
        'profile_image'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function category()
    {
        return $this->belongsTo(
            ProviderCategory::class,
            'provider_category_id'
        );
    }

    public function subCategory()
    {
        return $this->belongsTo(
            ProviderSubCategory::class,
            'provider_sub_category_id'
        );
    }
}
