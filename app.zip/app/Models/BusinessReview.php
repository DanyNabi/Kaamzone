<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BusinessReview extends Model
{
    protected $fillable = [
        'business_listing_id',
        'user_id',
        'guest_name',
        'guest_email',
        'guest_phone',
        'rating',
        'title',
        'review',
        'status',
        'ip_address',
        'user_agent',
        'approved_at',
    ];

    protected $casts = [
        'approved_at' => 'datetime',
    ];

    public function business()
    {
        return $this->belongsTo(BusinessListing::class, 'business_listing_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
