<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Resume extends Model
{
    protected $fillable = [
        'user_id',
        'title',
        'template',
        'is_default',
        'theme',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function personalInfo()
    {
        return $this->hasOne(ResumePersonalInfo::class);
    }

    public function experiences()
    {
        return $this->hasMany(ResumeExperience::class)
            ->orderBy('sort_order');
    }
    public function educations()
    {
        return $this->hasMany(ResumeEducation::class)
            ->orderBy('sort_order');
    }



    public function projects()
    {
        return $this->hasMany(ResumeProject::class)
            ->orderBy('sort_order')
            ->orderByDesc('id');
    }

    public function certifications()
    {
        return $this->hasMany(ResumeCertification::class)
            ->orderBy('sort_order')
            ->orderByDesc('id');
    }

    public function languages()
    {
        return $this->hasMany(ResumeLanguage::class)
            ->orderBy('sort_order')
            ->orderByDesc('id');
    }

    public function sections()
    {
        return $this->hasMany(ResumeSection::class)
            ->orderBy('sort_order');
    }

    public function references()
    {
        return $this->hasMany(ResumeReference::class)
            ->orderBy('sort_order')
            ->orderByDesc('id');
    }
    public function skills()
    {
        return $this->hasMany(ResumeSkill::class)
            ->orderBy('sort_order')
            ->orderByDesc('id');
    }
}
