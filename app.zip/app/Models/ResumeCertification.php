<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResumeCertification extends Model
{
    protected $fillable = [
        'resume_id',
        'name',
        'issuing_organization',
        'issue_date',
        'expiry_date',
        'credential_id',
        'credential_url',
        'sort_order',
    ];

    public function resume()
    {
        return $this->belongsTo(Resume::class);
    }
}