<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubscriptionFeature extends Model
{
    protected $fillable = [
        'module_id',
        'name',
        'slug',
        'type',
        'status',
    ];
    public function module()
    {
        return $this->belongsTo(SubscriptionModule::class, 'module_id');
    }

    public function planFeatures()
    {
        return $this->hasMany(
            SubscriptionPlanFeature::class,
            'feature_id'
        );
    }
}
