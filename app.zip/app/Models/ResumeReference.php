<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResumeReference extends Model
{
    protected $fillable = [
        'resume_id',
        'name',
        'position',
        'company',
        'email',
        'phone',
        'relationship',
        'sort_order',
    ];

    public function resume()
    {
        return $this->belongsTo(Resume::class);
    }
}