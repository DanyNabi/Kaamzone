<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProviderSubCategory extends Model
{
    protected $fillable = [
        'provider_category_id',
        'name',
        'slug',
        'status'
    ];

    public function category()
    {
        return $this->belongsTo(
            ProviderCategory::class,
            'provider_category_id'
        );
    }
}
