<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResumeCertificate extends Model
{
    protected $fillable = [
        'resume_id',
        'certificate_name',
        'issuing_organization',
        'issue_date',
        'expiry_date',
        'does_not_expire',
        'credential_id',
        'credential_url',
        'description',
        'sort_order',
    ];

    public function resume()
    {
        return $this->belongsTo(Resume::class);
    }
}
