<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmployerProfile extends Model
{
    protected $fillable = [

        'user_id',

        'company_logo',

        'company_name',

        'website',

        'industry',

        'company_size',

        'location',

        'about',

        'facebook',

        'linkedin',

        'twitter'

    ];

    public function employer()
    {
        return $this->belongsTo(
            User::class,
            'user_id'
        );
    }

}
