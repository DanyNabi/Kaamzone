<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResumeEducation extends Model
{
    protected $fillable = [
        'resume_id',
        'institution',
        'degree',
        'field_of_study',
        'grade',
        'start_date',
        'end_date',
        'currently_studying',
        'description',
    ];
    public function resume()
    {
        return $this->belongsTo(Resume::class);
    }
}
