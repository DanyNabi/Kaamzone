<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = ['name', 'slug', 'description'];

    public function products()
    {
        return $this->hasMany(\App\Models\Product::class);
    }

    public function providerCategories()
    {
        return $this->hasMany(ProviderCategory::class);
    }
    public function subCategories()
    {
        return $this->hasMany(SubCategory::class);
    }
}
