<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResumePersonalInfo extends Model
{
    protected $fillable = [
        'resume_id',

        // Basic Information
        'first_name',
        'last_name',
        'professional_title',

        // Contact
        'email',
        'phone',

        // Personal Details
        'date_of_birth',
        'gender',
        'nationality',

        // Address
        'country',
        'state',
        'city',
        'address',
        'postal_code',

        // Career
        'driving_license',

        // Links
        'website',
        'linkedin',
        'github',
        'portfolio',

        // Profile
        'profile_photo',

        // Summary
        'summary',
    ];

    public function resume()
    {
        return $this->belongsTo(Resume::class);
    }
}
