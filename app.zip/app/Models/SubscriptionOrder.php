<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubscriptionOrder extends Model
{
    protected $fillable = [

        'user_id',
        'module_id',
        'plan_id',

        'order_no',

        'amount',

        'payment_method',
        'transaction_id',

        'payment_status',

        'status',

        'notes',

        'paid_at',

        'payment_proof',
        'admin_note',

    ];

    protected $casts = [
        'paid_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function module()
    {
        return $this->belongsTo(SubscriptionModule::class);
    }

    public function plan()
    {
        return $this->belongsTo(SubscriptionPlan::class);
    }
}
