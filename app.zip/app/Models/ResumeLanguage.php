<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResumeLanguage extends Model
{
    protected $fillable = [
        'resume_id',
        'language',
        'proficiency',
        'sort_order',
    ];

    public function resume()
    {
        return $this->belongsTo(Resume::class);
    }
}