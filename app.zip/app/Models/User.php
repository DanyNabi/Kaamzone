<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use App\Models\ProviderCategoryPivot;
use Illuminate\Auth\Notifications\ResetPassword;
use App\Notifications\ResetPasswordNotification;



class User extends Authenticatable implements MustVerifyEmail
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;


    protected $fillable = [
        'name',
        'email',
        'password',
        'phone',
        'role',
        'profile_image',
        'status',
        'profile_reminder_sent_at',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];
    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'profile_reminder_sent_at' => 'datetime',
        ];
    }

    public function isRole($role)
    {
        return $this->role === $role;
    }

    public function dashboardUrl()
    {
        return match ($this->role) {
            'admin' => '/admin',
            'vendor' => '/vendors/dashboard',
            'employer' => '/employer/dashboard',
            'service_provider' => '/service/dashboard',
            'business' => '/business/dashboard',
            'job_seeker' => '/jobs',
            default => '/',
        };
    }

    public function profile()
    {
        return $this->hasOne(\App\Models\UserProfile::class);
    }

    public function reviewsReceived()
    {
        return $this->hasMany(Review::class, 'provider_id');
    }

    public function reviewsGiven()
    {
        return $this->hasMany(Review::class, 'user_id');
    }

    public function providerProfile()
    {
        return $this->hasOne(ProviderProfile::class);
    }


    public function providerCategories()
    {
        return $this->hasMany(
            ProviderCategoryPivot::class,
            'provider_id'
        );
    }

    public function bids()
    {
        return $this->hasMany(
            Bid::class,
            'provider_id'
        );
    }


    // RECEIVED REVIEWS

    public function receivedReviews()
    {
        return $this->hasMany(
            Review::class,
            'provider_id'
        );
    }

    // GIVEN REVIEWS

    public function givenReviews()
    {
        return $this->hasMany(
            Review::class,
            'user_id'
        );
    }
    public function provider_category()
    {
        return $this->hasMany(
            ProviderCategoryPivot::class,
            'provider_id'
        );
    }
    public function employerProfile()
    {
        return $this->hasOne(
            EmployerProfile::class
        );
    }

    public function jobSeekerProfile()
    {
        return $this->hasOne(
            JobSeekerProfile::class
        );
    }

    public function subscriptions()
    {
        return $this->hasMany(UserSubscription::class);
    }

    public function activeSubscription($moduleSlug)
    {
        return $this->hasOne(UserSubscription::class)
            ->whereHas('module', function ($q) use ($moduleSlug) {
                $q->where('slug', $moduleSlug);
            })
            ->where('status', 'active')
            ->where(function ($q) {
                $q->whereNull('expires_at')
                    ->orWhere('expires_at', '>=', now());
            });
    }
    public function businessReviews()
    {
        return $this->hasMany(BusinessReview::class);
    }

    public function resumes()
    {
        return $this->hasMany(Resume::class);
    }

    public function sendPasswordResetNotification($token)
    {
        $this->notify(new ResetPasswordNotification($token));
    }

    public function isProfileComplete(): bool
    {
        switch ($this->role) {

            case 'service_provider':

                $profile = $this->providerProfile;

                if (!$profile) {
                    return false;
                }

                return !empty($profile->bio)
                    && !empty($profile->skills)
                    && !empty($profile->experience)
                    && !empty($profile->profile_image);

            case 'employer':

                $profile = $this->employerProfile;

                if (!$profile) {
                    return false;
                }

                return !empty($profile->company_logo)
                    && !empty($profile->company_name)
                    && !empty($profile->industry)
                    && !empty($profile->company_size)
                    && !empty($profile->location)
                    && !empty($profile->about);

            case 'vendor':
            case 'business':
            case 'job_seeker':

                $profile = $this->profile;

                if (!$profile) {
                    return false;
                }

                return !empty($profile->address)
                    && !empty($profile->city)
                    && !empty($profile->country)
                    && !empty($profile->state)
                    && !empty($profile->zip_code)
                    && !empty($profile->about);

            default:
                return true;
        }
    }
}
