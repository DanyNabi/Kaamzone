<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CareerJob extends Model
{
    protected $table = 'career_jobs';

    protected $fillable = [

        'user_id',

        'title',

        'slug',

        'company_name',

        'job_category_id',

        'location',

        'job_type',

        'salary',

        'experience',

        'description',

        'status',
        'is_featured',
        'expires_at'

    ];

    // EMPLOYER

    public function employer()
    {
        return $this->belongsTo(
            User::class,
            'user_id'
        );
    }

    public function applications()
    {
        return $this->hasMany(
            JobApplication::class,
            'career_job_id'
        );
    }
    public function category()
    {
        return $this->belongsTo(
            JobCategory::class,
            'job_category_id'
        );
    }
}
