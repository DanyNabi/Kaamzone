<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BusinessListing extends Model
{
    protected $fillable = [

        'user_id',
        'category_id',
        'title',
        'slug',
        'description',
        'phone',
        'email',
        'address',
        'city',
        
        'latitude',
        'longitude',
        'logo',
        'cover_image',
        'video',
        'opening_days',
        'opening_time',
        'closing_time',

        'status',
    ];

    public function category()
    {
        return $this->belongsTo(BusinessCategory::class, 'category_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function reviews()
    {
        return $this->hasMany(BusinessReview::class);
    }
}
