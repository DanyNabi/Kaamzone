<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HeroSlider extends Model
{
    protected $fillable = [

        'page',

        'badge',

        'heading',

        'description',

        'button1_text',
        'button1_link',

        'button2_text',
        'button2_link',

        'image',

        'sort_order',

        'status'

    ];
}
