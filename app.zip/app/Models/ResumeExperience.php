<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResumeExperience extends Model
{
    protected $fillable = [

        'resume_id',

        'job_title',

        'company',

        'employment_type',

        'location',

        'currently_working',

        'start_date',

        'end_date',

        'description',

        'sort_order'
    ];

    public function resume()
{
    return $this->belongsTo(Resume::class);
}
}
