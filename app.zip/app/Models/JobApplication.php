<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobApplication extends Model
{
    protected $fillable = [

        'career_job_id',

        'user_id',

        'resume',

        'cover_letter',

        'status'

    ];

    // JOB

    public function job()
    {
        return $this->belongsTo(
            CareerJob::class,
            'career_job_id'
        );
    }

    // APPLICANT

    public function applicant()
    {
        return $this->belongsTo(
            User::class,
            'user_id'
        );
    }
}
