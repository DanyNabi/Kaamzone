<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Product extends Model
{
    protected $fillable = [
        'user_id',
        'title',
        'description',
        'price',
        'category_id',
        'sub_category_id',
        'image',
        'status',
        'is_featured',
        'featured_until',
        'video',
        'expires_at',
    ];

    public function category()
    {
        return $this->belongsTo(\App\Models\Category::class);
    }

    public function subCategory()
    {
        return $this->belongsTo(SubCategory::class);
    }
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }
    public function images()
    {
        return $this->hasMany(\App\Models\ProductImage::class);
    }

    protected static function booted()
    {
        static::creating(function ($product) {

            $slug = Str::slug($product->title);

            $count = self::where('slug', 'LIKE', "{$slug}%")->count();
            $product->slug = $count ? "{$slug}-{$count}" : $slug;
        });
    }
}
