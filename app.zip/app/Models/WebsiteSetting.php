<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WebsiteSetting extends Model
{
    protected $fillable = [

        'site_name',

        'logo',

        'tagline',


        'favicon',

        'desktop_logo_width',

        'mobile_logo_width'

    ];
}
