<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServiceRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',

        'provider_category_id',
        'provider_sub_category_id',

        'title',
        'description',
        'budget',
        'location',
        'deadline',
        'image',
        'status'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function bids()
    {
        return $this->hasMany(Bid::class);
    }
    public function images()
    {
        return $this->hasMany(ServiceRequestImage::class);
    }

    public function providerCategory()
    {
        return $this->belongsTo(
            ProviderCategory::class,
            'provider_category_id'
        );
    }

    public function assignedProvider()
    {
        return $this->belongsTo(
            User::class,
            'assigned_provider_id'
        );
    }

    public function acceptedBid()
    {
        return $this->belongsTo(
            Bid::class,
            'accepted_bid_id'
        );
    }

    public function review()
    {
        return $this->hasOne(
            Review::class,
            'bid_id',
            'accepted_bid_id'
        );
    }

    public function category()
    {
        return $this->belongsTo(
            ProviderCategory::class,
            'provider_category_id'
        );
    }

    public function subCategory()
    {
        return $this->belongsTo(
            ProviderSubCategory::class,
            'provider_sub_category_id'
        );
    }
}
