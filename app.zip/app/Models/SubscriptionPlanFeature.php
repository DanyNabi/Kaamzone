<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubscriptionPlanFeature extends Model
{
    protected $fillable = [
        'plan_id',
        'feature_id',
        'value',
        'is_unlimited',
    ];

    public function feature()
    {
        return $this->belongsTo(SubscriptionFeature::class);
    }

    public function plan()
    {
        return $this->belongsTo(SubscriptionPlan::class);
    }
}
