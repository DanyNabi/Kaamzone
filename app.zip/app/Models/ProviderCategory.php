<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProviderCategory extends Model
{
    protected $table = 'provider_categories';

    protected $fillable = [

        'name',

        'slug',

        'status'

    ];
    public function subCategories()
    {
        return $this->hasMany(
            ProviderSubCategory::class,
            'provider_category_id'
        );
    }
}
