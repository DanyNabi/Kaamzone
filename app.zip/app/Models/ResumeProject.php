<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResumeProject extends Model
{
    protected $fillable = [
        'resume_id',
        'title',
        'role',
        'description',
        'start_date',
        'end_date',
        'currently_working',
        'project_url',
        'sort_order',
    ];

    protected $casts = [
        'currently_working' => 'boolean',
    ];

    public function resume()
    {
        return $this->belongsTo(Resume::class);
    }
}