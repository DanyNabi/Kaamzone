<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserProfile extends Model
{
    protected $table = 'user_profiles';

    protected $fillable = [
        'user_id',
        'address',
        'city',
        'country',
        'state',
        'zip_code',
        'about',
    ];

    // 🔗 Relationship with User
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
