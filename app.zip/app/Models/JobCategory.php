<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobCategory extends Model
{
    protected $fillable = [

        'name',

        'slug',

        'icon'

    ];

    // JOBS

    public function careerJobs()
    {
        return $this->hasMany(
            CareerJob::class,
            'job_category_id'
        );
    }
}
