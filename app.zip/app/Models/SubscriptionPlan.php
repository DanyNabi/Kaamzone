<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubscriptionPlan extends Model
{
    protected $fillable = [
        'module_id',
        'name',
        'slug',
        'price',
        'billing_cycle',
        'duration',
        'trial_days',
        'description',
        'badge',
        'color',
        'is_popular',
        'is_featured',
        'status',
        'sort_order',
    ];

    public function module()
    {
        return $this->belongsTo(SubscriptionModule::class);
    }

    public function planFeatures()
    {
        return $this->hasMany(SubscriptionPlanFeature::class, 'plan_id');
    }

    
}
