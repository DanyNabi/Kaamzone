<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use App\Models\BusinessListing;

class BusinessCategory extends Model
{
    protected $fillable = [
        'name',
        'slug',
        'description'
    ];

    protected static function booted()
    {
        static::creating(function ($category) {

            $slug = Str::slug($category->name);

            $count = self::where('slug', 'LIKE', "{$slug}%")->count();

            $category->slug = $count
                ? "{$slug}-{$count}"
                : $slug;
        });
    }
    public function businessListings()
    {
        return $this->hasMany(
            BusinessListing::class,
            'category_id'
        );
    }
}
