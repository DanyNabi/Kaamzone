<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProviderCategoryPivot extends Model
{
    protected $table = 'provider_category';

    protected $fillable = [

        'provider_id',

        'provider_category_id'

    ];

    public function category()
    {
        return $this->belongsTo(
            ProviderCategory::class,
            'provider_category_id'
        );
    }

    
}