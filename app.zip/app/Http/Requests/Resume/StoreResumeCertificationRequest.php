<?php

namespace App\Http\Requests\Resume;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class StoreResumeCertificationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
        'name' => ['required', 'string', 'max:255'],

        'issuing_organization' => ['required', 'string', 'max:255'],

        'issue_date' => ['required', 'date'],

        'expiry_date' => ['nullable', 'date', 'after_or_equal:issue_date'],

        'credential_id' => ['nullable', 'string', 'max:255'],

        'credential_url' => ['nullable', 'url', 'max:255'],

        'sort_order' => ['nullable', 'integer'],
    ];
    }
}
