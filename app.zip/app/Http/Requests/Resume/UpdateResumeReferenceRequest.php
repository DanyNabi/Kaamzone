<?php

namespace App\Http\Requests\Resume;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateResumeReferenceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [

            'name' => ['required', 'string', 'max:255'],

            'position' => ['nullable', 'string', 'max:255'],

            'company' => ['nullable', 'string', 'max:255'],

            'email' => ['nullable', 'email', 'max:255'],

            'phone' => ['nullable', 'string', 'max:50'],

            'relationship' => [
                'required',
                'in:Manager,Supervisor,Colleague,Client,Professor,Other'
            ],

            'sort_order' => ['nullable', 'integer'],

        ];
    }
}
