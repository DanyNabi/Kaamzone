<?php

namespace App\Http\Requests\Resume;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class StoreResumePersonalInfoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'first_name'         => 'nullable|string|max:100',
            'last_name'          => 'nullable|string|max:100',
            'professional_title' => 'nullable|string|max:255',
            'email'              => 'nullable|email|max:255',
            'phone'              => 'nullable|string|max:30',

            'country'            => 'nullable|string|max:100',
            'state'              => 'nullable|string|max:100',
            'city'               => 'nullable|string|max:100',
            'address'            => 'nullable|string|max:255',
            'postal_code'        => 'nullable|string|max:20',

            'website'            => 'nullable|url|max:255',
            'linkedin'           => 'nullable|url|max:255',
            'github'             => 'nullable|url|max:255',
            'portfolio'          => 'nullable|url|max:255',

            'date_of_birth'      => 'nullable|date',
            'gender'             => 'nullable|in:male,female,other',
            'nationality'        => 'nullable|string|max:100',
            'driving_license'    => 'nullable|string|max:100',

            'summary'            => 'nullable|string|max:5000',

            'profile_photo'      => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ];
    }

    public function messages(): array
    {
        return [
            'email.email' => 'Please enter a valid email address.',
            'linkedin.url' => 'LinkedIn must be a valid URL.',
            'github.url' => 'GitHub must be a valid URL.',
            'portfolio.url' => 'Portfolio must be a valid URL.',
            'website.url' => 'Website must be a valid URL.',
            'profile_photo.image' => 'The profile photo must be an image.',
        ];
    }
}
