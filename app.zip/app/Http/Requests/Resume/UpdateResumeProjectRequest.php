<?php

namespace App\Http\Requests\Resume;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateResumeProjectRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [

        'title' => ['required', 'string', 'max:255'],

        'role' => ['nullable', 'string', 'max:255'],

        'description' => ['nullable', 'string'],

        'start_date' => ['nullable', 'date'],

        'end_date' => ['nullable', 'date', 'after_or_equal:start_date'],

        'currently_working' => ['nullable', 'boolean'],

        'project_url' => ['nullable', 'url', 'max:255'],

        'sort_order' => ['nullable', 'integer'],

    ];
    }
}
