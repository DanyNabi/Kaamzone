<?php

namespace App\Http\Requests\Resume;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateResumeSkillRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'skill' => ['required', 'string', 'max:255'],

            'level' => [
                'required',
                'in:Beginner,Intermediate,Advanced,Expert'
            ],

            'sort_order' => [
                'nullable',
                'integer'
            ],
        ];
    }
}
