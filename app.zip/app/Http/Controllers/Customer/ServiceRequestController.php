<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\ProviderCategory;
use App\Models\ServiceRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use App\Models\Bid;
use App\Models\Review;

class ServiceRequestController extends Controller
{

    public function index()
    {
        $requests = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
            ->latest()
            ->paginate(10);

        return view(
            'customer.requests.index',
            compact('requests')
        );
    }
    public function create()
    {
        $categories = ProviderCategory::where(
            'status',
            1
        )->get();

        return view(
            'customer.requests.create',
            compact('categories')
        );
    }

    public function store(Request $request)
    {
        $request->validate([

            'title' => 'required',

            'provider_category_id' => 'required',
            'provider_sub_category_id' => 'required',

            'description' => 'required',

            'budget' => 'required',

            'location' => 'nullable',

            'deadline' => 'nullable|date',

            'image' => 'nullable|image'

        ]);

        // IMAGE

        $imagePath = null;

        if ($request->hasFile('image')) {

            $image = $request->file('image');

            $imageName = time() . '.' .
                $image->getClientOriginalExtension();

            $image->move(
                public_path('uploads/requests'),
                $imageName
            );

            $imagePath =
                'uploads/requests/' . $imageName;
        }

        // SAVE REQUEST

        ServiceRequest::create([

            'user_id' => Auth::id(),

            'provider_category_id' =>
            $request->provider_category_id,

            'provider_sub_category_id' =>
            $request->provider_sub_category_id,
            'title' => $request->title,

            'description' => $request->description,

            'budget' => $request->budget,

            'location' => $request->location,

            'deadline' => $request->deadline,

            'image' => $imagePath,

            'status' => 'open'

        ]);

        return redirect()
            ->route('customer.dashboard')
            ->with(
                'success',
                'Service request submitted successfully.'
            );
    }

    public function show($id)
    {
        $request = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
            ->with([
                'bids.provider'
            ])
            ->findOrFail($id);

        return view(
            'customer.requests.show',
            compact('request')
        );
    }


    public function edit($id)
    {
        $requestData = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
            ->where('status', 'open')
            ->findOrFail($id);

        $categories = ProviderCategory::where(
            'status',
            1
        )->get();

        return view(
            'customer.requests.edit',
            compact(
                'requestData',
                'categories'
            )
        );
    }

    public function update(Request $request, $id)
    {
        $serviceRequest = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
            ->where('status', 'open')
            ->findOrFail($id);

        $request->validate([

            'title' => 'required',

            'provider_category_id' => 'required',
            'provider_sub_category_id' => 'required',

            'description' => 'required',

            'budget' => 'required'

        ]);

        // IMAGE

        if ($request->hasFile('image')) {

            $image = $request->file('image');

            $imageName = time() . '.' .
                $image->getClientOriginalExtension();

            $image->move(
                public_path('uploads/requests'),
                $imageName
            );

            $serviceRequest->image =
                'uploads/requests/' . $imageName;
        }

        // UPDATE

        $serviceRequest->provider_category_id =
            $request->provider_category_id;

        $serviceRequest->provider_sub_category_id =
            $request->provider_sub_category_id;

        $serviceRequest->title =
            $request->title;

        $serviceRequest->description =
            $request->description;

        $serviceRequest->budget =
            $request->budget;

        $serviceRequest->location =
            $request->location;

        $serviceRequest->deadline =
            $request->deadline;

        $serviceRequest->save();

        return redirect()
            ->route('customer.requests.show', $id)
            ->with(
                'success',
                'Request updated successfully.'
            );
    }

    public function destroy($id)
    {
        $serviceRequest = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
            ->where('status', 'open')
            ->findOrFail($id);

        $serviceRequest->delete();

        return redirect()
            ->route('customer.requests')
            ->with(
                'success',
                'Request deleted successfully.'
            );
    }

    public function hireProvider($id)
    {
        $bid = Bid::with('serviceRequest')
            ->findOrFail($id);

        $serviceRequest = $bid->serviceRequest;

        // SECURITY CHECK

        if ($serviceRequest->user_id != Auth::id()) {

            abort(403);
        }

        // UPDATE REQUEST

        $serviceRequest->assigned_provider_id =
            $bid->provider_id;

        $serviceRequest->accepted_bid_id =
            $bid->id;

        $serviceRequest->status =
            'in_progress';

        $serviceRequest->save();

        // ACCEPT THIS BID

        $bid->status = 'accepted';

        $bid->save();

        // REJECT OTHER BIDS

        Bid::where(
            'service_request_id',
            $serviceRequest->id
        )
            ->where('id', '!=', $bid->id)
            ->update([
                'status' => 'rejected'
            ]);

        return back()->with(
            'success',
            'Provider hired successfully.'
        );
    }

    public function jobs()
    {
        $jobs = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
            ->whereIn('status', [
                'in_progress',
                'completed'
            ])
            ->with([
                'assignedProvider',
                'acceptedBid'
            ])
            ->latest()
            ->paginate(10);

        return view(
            'customer.jobs.index',
            compact('jobs')
        );
    }

    public function completeJob($id)
    {
        $job = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
            ->where('status', 'in_progress')
            ->findOrFail($id);

        // UPDATE STATUS

        $job->status = 'completed';

        $job->save();

        // UPDATE ACCEPTED BID STATUS

        if ($job->acceptedBid) {

            $job->acceptedBid->status =
                'completed';

            $job->acceptedBid->save();
        }

        return back()->with(
            'success',
            'Job marked as completed.'
        );
    }

    public function storeReview(Request $request, $id)
    {
        $job = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
            ->where('status', 'completed')
            ->with('acceptedBid')
            ->findOrFail($id);

        // PREVENT DUPLICATE REVIEW

        $existingReview = Review::where(
            'bid_id',
            optional($job->acceptedBid)->id
        )->first();

        if ($existingReview) {

            return back()->with(
                'error',
                'Review already submitted.'
            );
        }

        // VALIDATION

        $request->validate([

            'rating' => 'required|integer|min:1|max:5',

            'comment' => 'nullable'

        ]);

        // SAVE REVIEW

        Review::create([

            'user_id' => Auth::id(),

            'provider_id' =>
            $job->assigned_provider_id,

            'bid_id' =>
            optional($job->acceptedBid)->id,

            'rating' => $request->rating,

            'comment' => $request->comment

        ]);

        return back()->with(
            'success',
            'Review submitted successfully.'
        );
    }
}
