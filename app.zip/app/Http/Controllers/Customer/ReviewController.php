<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Bid;
use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class ReviewController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'bid_id' => 'required',
            'rating' => 'required|min:1|max:5',
            'comment' => 'nullable'
        ]);

        $bid = Bid::findOrFail($request->bid_id);

        // Prevent duplicate review

        $exists = Review::where('bid_id', $bid->id)->exists();

        if ($exists) {

            return back()->with(
                'error',
                'Review already submitted.'
            );
        }

        Review::create([

            'user_id' => Auth::id(),

            'provider_id' => $bid->provider_id,

            'bid_id' => $bid->id,

            'rating' => $request->rating,

            'comment' => $request->comment

        ]);

        return back()->with(
            'success',
            'Review submitted successfully.'
        );
    }
}
