<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\ServiceRequest;
use App\Models\Bid;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Models\UserProfile;

class DashboardController extends Controller
{
     public function index()
    {
        // TOTAL REQUESTS

        $totalRequests = ServiceRequest::where(
            'user_id',
            Auth::id()
        )->count();

        // OPEN REQUESTS

        $openRequests = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
        ->where('status', 'open')
        ->count();

        // COMPLETED JOBS

        $completedJobs = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
        ->where('status', 'completed')
        ->count();

        // TOTAL BIDS

        $totalBids = Bid::whereHas(
            'serviceRequest',
            function ($query) {

                $query->where(
                    'user_id',
                    Auth::id()
                );

            }
        )->count();

        // RECENT REQUESTS

        $recentRequests = ServiceRequest::where(
            'user_id',
            Auth::id()
        )
        ->latest()
        ->take(5)
        ->get();

        return view(
            'customer.dashboard',
            compact(
                'totalRequests',
                'openRequests',
                'completedJobs',
                'totalBids',
                'recentRequests'
            )
        );
    }

    public function updateProfile(Request $request)
    {
        $user = Auth::user();

        // ✅ Validation (email unique fix)
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'email',
                Rule::unique('users')->ignore($user->id),
            ],
            'phone' => 'nullable|string|max:20',
            'profile_image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        // ✅ Update fields
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;

        // ✅ Image Upload
        if ($request->hasFile('profile_image')) {

            // OLD IMAGE DELETE (important)
            if ($user->profile_image && file_exists(public_path('uploads/users/' . $user->profile_image))) {
                unlink(public_path('uploads/users/' . $user->profile_image));
            }

            $file = $request->file('profile_image');
            $filename = time() . '.' . $file->getClientOriginalExtension();

            $file->move(public_path('uploads/users'), $filename);

            $user->profile_image = $filename;
        }

        $user->save();

        return back()->with('success', 'Profile updated successfully');
    }

    public function updateDetails(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'address' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:100',
            'country' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:100',
            'zip_code' => 'nullable|string|max:20',
            'about' => 'nullable|string',
        ]);

        UserProfile::updateOrCreate(
            ['user_id' => $user->id],
            [
                'address' => $request->address,
                'city' => $request->city,
                'country' => $request->country,
                'state' => $request->state,
                'zip_code' => $request->zip_code,
                'about' => $request->about,
            ]
        );

        return back()->with('success', 'Profile details updated');
    }
}
