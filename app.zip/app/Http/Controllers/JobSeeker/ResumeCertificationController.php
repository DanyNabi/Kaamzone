<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use App\Http\Requests\Resume\StoreResumeCertificationRequest;
use App\Http\Requests\Resume\UpdateResumeCertificationRequest;
use App\Models\Resume;
use App\Models\ResumeCertification;
use App\Services\ResumeCertificationService;
use Illuminate\Support\Facades\Auth;

class ResumeCertificationController extends Controller
{
    public function __construct(
        protected ResumeCertificationService $resumeCertificationService
    ) {}

    public function store(
        StoreResumeCertificationRequest $request,
        Resume $resume
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        $certification = $this->resumeCertificationService->create(
            $resume->id,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Certification added successfully.',
            'html' => view(
                'seeker.resumes.forms.certification-card',
                compact('certification')
            )->render(),
            'data' => $certification,
        ]);
    }

    public function update(
        UpdateResumeCertificationRequest $request,
        Resume $resume,
        ResumeCertification $certification
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        abort_if($certification->resume_id !== $resume->id, 404);

        $certification = $this->resumeCertificationService->update(
            $certification,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Certification updated successfully.',
            'html' => view(
                'seeker.resumes.forms.certification-card',
                compact('certification')
            )->render(),
            'data' => $certification,
        ]);
    }

    public function destroy(
        Resume $resume,
        ResumeCertification $certification
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        abort_if($certification->resume_id !== $resume->id, 404);

        $this->resumeCertificationService->delete($certification);

        return response()->json([
            'success' => true,
            'message' => 'Certification deleted successfully.',
        ]);
    }
}