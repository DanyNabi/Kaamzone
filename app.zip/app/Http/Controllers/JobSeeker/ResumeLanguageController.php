<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use App\Http\Requests\Resume\StoreResumeLanguageRequest;
use App\Http\Requests\Resume\UpdateResumeLanguageRequest;
use App\Models\Resume;
use App\Models\ResumeLanguage;
use App\Services\ResumeLanguageService;
use Illuminate\Support\Facades\Auth;

class ResumeLanguageController extends Controller
{
    public function __construct(
        protected ResumeLanguageService $resumeLanguageService
    ) {}

    public function store(
        StoreResumeLanguageRequest $request,
        Resume $resume
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        $language = $this->resumeLanguageService->create(
            $resume->id,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Language added successfully.',
            'html' => view(
                'seeker.resumes.forms.language-card',
                compact('language')
            )->render(),
            'data' => $language,
        ]);
    }

    public function update(
        UpdateResumeLanguageRequest $request,
        Resume $resume,
        ResumeLanguage $language
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        abort_if($language->resume_id !== $resume->id, 404);

        $language = $this->resumeLanguageService->update(
            $language,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Language updated successfully.',
            'html' => view(
                'seeker.resumes.forms.language-card',
                compact('language')
            )->render(),
            'data' => $language,
        ]);
    }

    public function destroy(
        Resume $resume,
        ResumeLanguage $language
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        abort_if($language->resume_id !== $resume->id, 404);

        $this->resumeLanguageService->delete($language);

        return response()->json([
            'success' => true,
            'message' => 'Language deleted successfully.',
        ]);
    }
}