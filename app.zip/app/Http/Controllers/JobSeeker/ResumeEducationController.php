<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use App\Http\Requests\Resume\StoreResumeEducationRequest;
use App\Http\Requests\Resume\UpdateResumeEducationRequest;
use App\Models\Resume;
use App\Models\ResumeEducation;
use App\Services\ResumeEducationService;
use Illuminate\Support\Facades\Auth;

class ResumeEducationController extends Controller
{
    protected $resumeEducationService;

    public function __construct(
        ResumeEducationService $resumeEducationService
    ) {
        $this->resumeEducationService = $resumeEducationService;
    }

    public function store(
        StoreResumeEducationRequest $request,
        Resume $resume
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        $education = $this->resumeEducationService->create(
            $resume->id,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Education added successfully.',
            'html' => view(
                'seeker.resumes.forms.education-card',
                compact('education')
            )->render(),
            'data' => $education,
        ]);
    }

    public function update(
        UpdateResumeEducationRequest $request,
        Resume $resume,
        ResumeEducation $education
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        if ($education->resume_id !== $resume->id) {
            abort(404);
        }

        $education = $this->resumeEducationService->update(
            $education->id,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Education updated successfully.',
            'html' => view(
                'seeker.resumes.forms.education-card',
                compact('education')
            )->render(),
            'data' => $education,
        ]);
    }

    public function destroy(
        Resume $resume,
        ResumeEducation $education
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        if ($education->resume_id !== $resume->id) {
            abort(404);
        }

        $this->resumeEducationService->delete($education->id);

        return response()->json([
            'success' => true,
            'message' => 'Education deleted successfully.',
        ]);
    }
}