<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use App\Models\JobSeekerProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class JobSeekerProfileController extends Controller
{
    public function edit()
    {
        $profile = JobSeekerProfile::firstOrCreate([

            'user_id' => Auth::id()

        ]);

        return view(
            'seeker.seeker-profile.edit',
            compact('profile')
        );
    }

    public function update(Request $request)
    {
        $profile = JobSeekerProfile::firstOrCreate([

            'user_id' => Auth::id()

        ]);

        // IMAGE

        if ($request->hasFile('profile_image')) {

            $image = $request->file('profile_image');

            $imageName = time() . '.' .
                $image->getClientOriginalExtension();

            $image->move(
                public_path('uploads/jobseekers'),
                $imageName
            );

            $profile->profile_image =
                'uploads/jobseekers/' . $imageName;
        }

        // RESUME

        if ($request->hasFile('resume')) {

            $resume = $request->file('resume');

            $resumeName = time() . '.' .
                $resume->getClientOriginalExtension();

            $resume->move(
                public_path('uploads/resumes'),
                $resumeName
            );

            $profile->resume =
                'uploads/resumes/' . $resumeName;
        }

        // SAVE

        $profile->bio =
            $request->bio;

        $profile->skills =
            $request->skills;

        $profile->experience =
            $request->experience;

        $profile->education =
            $request->education;

        $profile->location =
            $request->location;

        $profile->save();

        return back()->with(
            'success',
            'Profile updated successfully.'
        );
    }
}