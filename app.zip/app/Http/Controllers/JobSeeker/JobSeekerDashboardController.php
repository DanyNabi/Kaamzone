<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\UserProfile;
use Illuminate\Validation\Rule;
use App\Models\CareerJob;
use App\Models\JobApplication;
use App\Models\JobSeekerProfile;


class JobSeekerDashboardController extends Controller
{
    public function index()
    {
        // APPLICATIONS

        $applications = JobApplication::where(
            'user_id',
            Auth::id()
        )
            ->with('job')
            ->latest()
            ->paginate(10);

        // STATS

        $totalApplications = JobApplication::where(
            'user_id',
            Auth::id()
        )->count();

        $pendingApplications = JobApplication::where(
            'user_id',
            Auth::id()
        )
            ->where(
                'status',
                'pending'
            )
            ->count();

        $shortlistedApplications = JobApplication::where(
            'user_id',
            Auth::id()
        )
            ->where(
                'status',
                'shortlisted'
            )
            ->count();

        $acceptedApplications = JobApplication::where(
            'user_id',
            Auth::id()
        )
            ->where(
                'status',
                'accepted'
            )
            ->count();

        return view(
            'seeker.dashboard',
            compact(
                'applications',
                'totalApplications',
                'pendingApplications',
                'shortlistedApplications',
                'acceptedApplications'
            )
        );
    }

    public function updateProfile(Request $request)
    {
        $user = Auth::user();

        // ✅ Validation (email unique fix)
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'email',
                Rule::unique('users')->ignore($user->id),
            ],
            'phone' => 'nullable|string|max:20',
            'profile_image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        // ✅ Update fields
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;

        // ✅ Image Upload
        if ($request->hasFile('profile_image')) {

            // OLD IMAGE DELETE (important)
            if ($user->profile_image && file_exists(public_path('uploads/users/' . $user->profile_image))) {
                unlink(public_path('uploads/users/' . $user->profile_image));
            }

            $file = $request->file('profile_image');
            $filename = time() . '.' . $file->getClientOriginalExtension();

            $file->move(public_path('uploads/users'), $filename);

            $user->profile_image = $filename;
        }

        $user->save();

        return back()->with('success', 'Profile updated successfully');
    }

    public function updateDetails(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'address' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:100',
            'country' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:100',
            'zip_code' => 'nullable|string|max:20',
            'about' => 'nullable|string',
        ]);

        UserProfile::updateOrCreate(
            ['user_id' => $user->id],
            [
                'address' => $request->address,
                'city' => $request->city,
                'country' => $request->country,
                'state' => $request->state,
                'zip_code' => $request->zip_code,
                'about' => $request->about,
            ]
        );

        return back()->with('success', 'Profile details updated');
    }

    public function jobs()
    {
        $jobs = CareerJob::where(
            'status',
            'active'
        )
            ->latest()
            ->paginate(12);

        return view(
            'seeker.jobs.index',
            compact('jobs')
        );
    }

    public function applications()
    {
        $applications = JobApplication::where(
            'user_id',
            Auth::id()
        )
            ->with('job')
            ->latest()
            ->paginate(10);

        return view(
            'seeker.applications.index',
            compact('applications')
        );
    }

    public function apply(Request $request, $id)
    {
        $job = CareerJob::findOrFail($id);

        // ALREADY APPLIED

        $alreadyApplied = JobApplication::where(
            'career_job_id',
            $job->id
        )
            ->where(
                'user_id',
                Auth::id()
            )
            ->exists();

        if ($alreadyApplied) {

            return back()->with(
                'error',
                'You already applied.'
            );
        }

        // PROFILE

        $profile = JobSeekerProfile::where(
            'user_id',
            Auth::id()
        )->first();

        // CREATE APPLICATION

        JobApplication::create([

            'career_job_id' => $job->id,

            'user_id' => Auth::id(),

            'resume' => optional($profile)->resume,

            'cover_letter' =>
            $request->cover_letter,

            'status' => 'pending'

        ]);

        return back()->with(
            'success',
            'Application submitted successfully.'
        );
    }
}
