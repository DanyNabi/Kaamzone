<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use App\Http\Requests\Resume\StoreResumePersonalInfoRequest;
use App\Models\Resume;
use App\Services\ResumePersonalInfoService;
use Illuminate\Support\Facades\Auth;

class ResumePersonalInfoController extends Controller
{
    protected $resumePersonalInfoService;

    public function __construct(
        ResumePersonalInfoService $resumePersonalInfoService
    ) {
        $this->resumePersonalInfoService = $resumePersonalInfoService;
    }

    public function store(
        StoreResumePersonalInfoRequest $request,
        Resume $resume
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        $personalInfo = $this->resumePersonalInfoService->updateOrCreate(
            $resume->id,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Personal information saved successfully.',
            'data' => $personalInfo,
        ]);
    }
}