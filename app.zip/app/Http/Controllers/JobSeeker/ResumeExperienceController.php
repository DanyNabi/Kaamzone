<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use App\Http\Requests\Resume\StoreResumeExperienceRequest;
use App\Http\Requests\Resume\UpdateResumeExperienceRequest;
use App\Models\Resume;
use App\Models\ResumeExperience;
use App\Services\ResumeExperienceService;
use Illuminate\Support\Facades\Auth;

class ResumeExperienceController extends Controller
{
    protected $resumeExperienceService;

    public function __construct(
        ResumeExperienceService $resumeExperienceService
    ) {
        $this->resumeExperienceService = $resumeExperienceService;
    }


    public function store(
        StoreResumeExperienceRequest $request,
        Resume $resume
    ) {
        abort_if($resume->user_id !== AUTH::id(), 403);

        $experience = $this->resumeExperienceService->create(
            $resume->id,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Experience added successfully.',
            'html' => view(
                'seeker.resumes.forms.experience-card',
                compact('experience')
            )->render(),
            'data' => $experience,
        ]);
    }

    public function update(
        UpdateResumeExperienceRequest $request,
        Resume $resume,
        ResumeExperience $experience
    ) {
        abort_if($resume->user_id !== AUTH::id(), 403);

        if ($experience->resume_id !== $resume->id) {
            abort(404);
        }

        $experience = $this->resumeExperienceService->update(
            $experience->id,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Experience updated successfully.',
            'html' => view(
                'seeker.resumes.forms.experience-card',
                compact('experience')
            )->render(),
            'data' => $experience,
        ]);
    }

    public function destroy(
        Resume $resume,
        ResumeExperience $experience
    ) {
        abort_if($resume->user_id !== AUTH::id(), 403);

        if ($experience->resume_id !== $resume->id) {
            abort(404);
        }

        $this->resumeExperienceService->delete($experience->id);

        return response()->json([
            'success' => true,
            'message' => 'Experience deleted successfully.',
        ]);
    }
}
