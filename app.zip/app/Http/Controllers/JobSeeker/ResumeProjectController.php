<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use App\Http\Requests\Resume\StoreResumeProjectRequest;
use App\Http\Requests\Resume\UpdateResumeProjectRequest;
use App\Models\Resume;
use App\Models\ResumeProject;
use App\Services\ResumeProjectService;
use Illuminate\Support\Facades\Auth;

class ResumeProjectController extends Controller
{
    public function __construct(
        protected ResumeProjectService $resumeProjectService
    ) {}

    public function store(
        StoreResumeProjectRequest $request,
        Resume $resume
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        $project = $this->resumeProjectService->create(
            $resume->id,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Project added successfully.',
            'html' => view(
                'seeker.resumes.forms.project-card',
                compact('project')
            )->render(),
            'data' => $project,
        ]);
    }

    public function update(
        UpdateResumeProjectRequest $request,
        Resume $resume,
        ResumeProject $project
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        abort_if($project->resume_id !== $resume->id, 404);

        $project = $this->resumeProjectService->update(
            $project,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Project updated successfully.',
            'html' => view(
                'seeker.resumes.forms.project-card',
                compact('project')
            )->render(),
            'data' => $project,
        ]);
    }

    public function destroy(
        Resume $resume,
        ResumeProject $project
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        abort_if($project->resume_id !== $resume->id, 404);

        $this->resumeProjectService->delete($project);

        return response()->json([
            'success' => true,
            'message' => 'Project deleted successfully.',
        ]);
    }
}