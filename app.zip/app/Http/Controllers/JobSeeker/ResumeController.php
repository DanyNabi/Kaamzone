<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Resume\StoreResumeRequest;
use App\Http\Requests\Resume\UpdateResumeRequest;
use App\Models\Resume;
use App\Services\ResumeService;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade\Pdf;

class ResumeController extends Controller
{

    public function __construct(
        protected ResumeService $resumeService
    ) {}

    public function index()
    {
        $resumes = $this->resumeService
            ->getUserResumes(Auth::id());

        return view('seeker.resumes.index', compact('resumes'));
    }

    public function create()
    {
        return view('seeker.resumes.create');
    }

    public function store(StoreResumeRequest $request)
    {
        $data = $request->validated();

        $data['user_id'] = Auth::id();

        $resume = $this->resumeService->create($data);

        return redirect()
            ->route('seeker.resumes.builder', $resume)
            ->with('success', 'Resume created successfully.');
    }

    public function edit(Resume $resume)
    {
        abort_if($resume->user_id != Auth::id(), 403);

        return view('resume.edit', compact('resume'));
    }

    public function update(
        UpdateResumeRequest $request,
        Resume $resume
    ) {
        abort_if($resume->user_id != Auth::id(), 403);

        $this->resumeService
            ->update($resume, $request->validated());

        return back()->with(
            'success',
            'Resume updated successfully.'
        );
    }

    public function destroy(Resume $resume)
    {
        abort_if($resume->user_id != Auth::id(), 403);

        $this->resumeService->delete($resume);

        return redirect()
            ->route('seeker.resumes.index')
            ->with('success', 'Resume deleted successfully.');
    }

    public function builder(Resume $resume)
    {
        abort_if($resume->user_id !== Auth::id(), 403);

        $resume = $this->resumeService->builder($resume->id);

        return view('seeker.resumes.builder', compact('resume'));
    }


    public function preview(Resume $resume)
    {
        $resume->load([
            'personalInfo',
            'experiences',
            'educations',
            'skills',
            'languages',
            'certifications',
            'projects',
            'references',
        ]);

        $template = $resume->template ?? 'modern';

        if (!view()->exists("seeker.resumes.preview.templates.$template")) {
            $template = 'modern';
        }

        return view(
            "seeker.resumes.preview.templates.$template",
            compact('resume')
        );
    }

    public function print(Resume $resume)
    {
        return view('seeker.resumes.preview.index', compact('resume'));
    }

    public function download(Resume $resume)
    {
        abort_if($resume->user_id !== Auth::id(), 403);

        $resume->load([
            'personalInfo',
            'experiences',
            'educations',
            'skills',
            'languages',
            'certifications',
            'projects',
            'references',
        ]);

        $pdf = Pdf::loadView(
            'seeker.resumes.preview.templates.modern',
            compact('resume')
        );

        $pdf->setPaper('a4', 'portrait');

        return $pdf->download(
            'resume-' . $resume->id . '.pdf'
        );
    }

    public function updateTheme(Request $request, Resume $resume)
    {
        abort_if($resume->user_id !== Auth::id(), 403);

        $request->validate([
            'theme' => 'required|in:blue,green,purple,dark,red'
        ]);

        $resume->update([
            'theme' => $request->theme
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Theme updated successfully.'
        ]);
    }
}
