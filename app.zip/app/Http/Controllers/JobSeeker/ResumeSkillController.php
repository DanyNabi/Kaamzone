<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use App\Http\Requests\Resume\StoreResumeSkillRequest;
use App\Http\Requests\Resume\UpdateResumeSkillRequest;
use App\Models\Resume;
use App\Models\ResumeSkill;
use App\Services\ResumeSkillService;
use Illuminate\Support\Facades\Auth;

class ResumeSkillController extends Controller
{
    public function __construct(
        protected ResumeSkillService $resumeSkillService
    ) {}

    public function store(
        StoreResumeSkillRequest $request,
        Resume $resume
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        $skill = $this->resumeSkillService->create(
            $resume->id,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Skill added successfully.',
            'html' => view(
                'seeker.resumes.forms.skill-card',
                compact('skill')
            )->render(),
            'data' => $skill,
        ]);
    }

    public function update(
        UpdateResumeSkillRequest $request,
        Resume $resume,
        ResumeSkill $skill
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        abort_if($skill->resume_id !== $resume->id, 404);

        $skill = $this->resumeSkillService->update(
            $skill,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Skill updated successfully.',
            'html' => view(
                'seeker.resumes.forms.skill-card',
                compact('skill')
            )->render(),
            'data' => $skill,
        ]);
    }

    public function destroy(
        Resume $resume,
        ResumeSkill $skill
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        abort_if($skill->resume_id !== $resume->id, 404);

        $this->resumeSkillService->delete($skill);

        return response()->json([
            'success' => true,
            'message' => 'Skill deleted successfully.',
        ]);
    }
}