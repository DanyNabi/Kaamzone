<?php

namespace App\Http\Controllers\JobSeeker;

use App\Http\Controllers\Controller;
use App\Http\Requests\Resume\StoreResumeReferenceRequest;
use App\Http\Requests\Resume\UpdateResumeReferenceRequest;
use App\Models\Resume;
use App\Models\ResumeReference;
use App\Services\ResumeReferenceService;
use Illuminate\Support\Facades\Auth;

class ResumeReferenceController extends Controller
{
    public function __construct(
        protected ResumeReferenceService $resumeReferenceService
    ) {}

    public function store(
        StoreResumeReferenceRequest $request,
        Resume $resume
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        $reference = $this->resumeReferenceService->create(
            $resume->id,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Reference added successfully.',
            'html' => view(
                'seeker.resumes.forms.reference-card',
                compact('reference')
            )->render(),
            'data' => $reference,
        ]);
    }

    public function update(
        UpdateResumeReferenceRequest $request,
        Resume $resume,
        ResumeReference $reference
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        abort_if($reference->resume_id !== $resume->id, 404);

        $reference = $this->resumeReferenceService->update(
            $reference,
            $request->validated()
        );

        return response()->json([
            'success' => true,
            'message' => 'Reference updated successfully.',
            'html' => view(
                'seeker.resumes.forms.reference-card',
                compact('reference')
            )->render(),
            'data' => $reference,
        ]);
    }

    public function destroy(
        Resume $resume,
        ResumeReference $reference
    ) {
        abort_if($resume->user_id !== Auth::id(), 403);

        abort_if($reference->resume_id !== $resume->id, 404);

        $this->resumeReferenceService->delete($reference);

        return response()->json([
            'success' => true,
            'message' => 'Reference deleted successfully.',
        ]);
    }
}