<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use App\Models\HeroSlider;
use App\Models\Product;
use App\Models\BusinessListing;

class HomeController extends Controller
{
    public function index()
    {
        $sliders = HeroSlider::where('page', 'home')
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();

        $featuredBusinessVideos = BusinessListing::where('status', 'approved')
            ->where('is_featured', 1)
            ->whereNotNull('video')
            ->latest()
            ->get();

        return view('home', compact(
            'sliders',
            'featuredBusinessVideos'
        ));
    }
}
