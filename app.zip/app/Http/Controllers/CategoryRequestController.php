<?php

namespace App\Http\Controllers;

use App\Models\CategoryRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CategoryRequestController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'type' => 'required|in:vendor,business,service_provider,job',

            'category_name' => [
                'required',
                'string',
                'max:255',
            ],

            'subcategory_name' => [
                'nullable',
                'string',
                'max:255',
            ],

            'description' => [
                'nullable',
                'string',
                'max:2000',
            ],
        ]);

        CategoryRequest::create([
            'user_id' => Auth::id(),
            'type' => $request->type,
            'category_name' => $request->category_name,
            'subcategory_name' => $request->subcategory_name,
            'description' => $request->description,
            'status' => 'pending',
        ]);

        return back()->with(
            'success',
            'Your category request has been submitted successfully.'
        );
    }
}