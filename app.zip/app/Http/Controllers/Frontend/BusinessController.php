<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BusinessListing;
use App\Models\BusinessCategory;
use App\Models\HeroSlider;
use App\Models\SubscriptionModule;
use App\Models\SubscriptionPlan;

class BusinessController extends Controller
{
    // ALL BUSINESSES
    public function index(Request $request)
    {
        $query = BusinessListing::where('status', 'approved');

        // SEARCH
        if ($request->keyword) {

            $query->where('title', 'like', '%' . $request->keyword . '%');
        }

        // CATEGORY FILTER
        if ($request->category) {

            $query->where('category_id', $request->category);
        }

        $listings = $query->latest()->paginate(9);

        $categories = BusinessCategory::with('businessListings')->get();

        $sliders = HeroSlider::where('page', 'businesses')
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();

        $buySellModule = SubscriptionModule::where('slug', 'business')->first();

        $plans = SubscriptionPlan::with('planFeatures.feature')
            ->where('module_id', $buySellModule->id)
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();

        $featuredBusinessVideos = BusinessListing::where('status', 'approved')
            ->where('is_featured', 1)
            ->whereNotNull('video')
            ->latest()
            ->get();

        return view(
            'frontend.business.index',
            compact('listings', 'categories', 'sliders', 'plans', 'featuredBusinessVideos')
        );
    }

    // SINGLE BUSINESS
    public function show($slug)
    {
        // CURRENT BUSINESS
        $listing = BusinessListing::with('category')
            ->where('slug', $slug)
            ->firstOrFail();

        // RELATED BUSINESSES
        $relatedBusinesses = BusinessListing::where(
            'category_id',
            $listing->category_id
        )
            ->where('id', '!=', $listing->id)
            ->where('status', 'approved')
            ->latest()
            ->take(4)
            ->get();

        // APPROVED REVIEWS
        $reviews = $listing->reviews()
            ->where('status', 'approved')
            ->latest()
            ->get();

        // AVERAGE RATING
        $averageRating = round(
            $listing->reviews()
                ->where('status', 'approved')
                ->avg('rating') ?? 0,
            1
        );

        // TOTAL REVIEWS
        $totalReviews = $listing->reviews()
            ->where('status', 'approved')
            ->count();

        return view(
            'frontend.business.show',
            compact(
                'listing',
                'relatedBusinesses',
                'reviews',
                'averageRating',
                'totalReviews'
            )
        );
    }

    public function category($slug)
    {
        $category = BusinessCategory::where('slug', $slug)->firstOrFail();

        $listings = BusinessListing::with('category')
            ->withAvg([
                'reviews' => function ($query) {
                    $query->where('status', 'approved');
                }
            ], 'rating')
            ->withCount([
                'reviews' => function ($query) {
                    $query->where('status', 'approved');
                }
            ])
            ->where('category_id', $category->id)
            ->where('status', 'approved')
            ->latest()
            ->paginate(9);

        $categories = BusinessCategory::all();

  $featuredBusinessVideos = BusinessListing::where('status', 'approved')
            ->where('is_featured', 1)
            ->where('category_id', $category->id)
            ->whereNotNull('video')
            ->latest()
            ->get();


        return view(
            'frontend.business.category',
            compact(
                'category',
                'listings',
                'categories',
                'featuredBusinessVideos'
            )
        );
    }
}
