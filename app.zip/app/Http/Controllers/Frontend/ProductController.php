<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\SubCategory;

class ProductController extends Controller
{
    public function show($slug)
    {
        $product = Product::with(['user.profile', 'category', 'images'])
            ->where('slug', $slug)
            ->where('status', 'approved')
            ->firstOrFail();

        // related products
        $related = Product::where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->where('status', 'approved')
            ->take(4)
            ->get();



        return view('frontend.product.show', compact('product', 'related'));
    }
    public function index(Request $request)
    {
        $query = Product::with(['user.profile', 'category'])
            ->where('status', 'approved');

        // 🔍 SEARCH
        if ($request->search) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        // 📂 CATEGORY
        if ($request->category) {
            $query->where('category_id', $request->category);
        }

        // 📍 LOCATION
        if ($request->location) {
            $query->whereHas('user.profile', function ($q) use ($request) {
                $q->where('city', $request->location);
            });
        }

        // 💰 PRICE FILTER
        if ($request->price) {
            if ($request->price == 'under50') {
                $query->where('price', '<', 50000);
            } elseif ($request->price == '50to100') {
                $query->whereBetween('price', [50000, 100000]);
            } elseif ($request->price == '100plus') {
                $query->where('price', '>', 100000);
            }
        }

        $products = $query->latest()->paginate(12);

        $categories = Category::all();




        return view('frontend.product.index', compact('products', 'categories'));
    }
    public function category(Request $request, $slug)
    {
        $category = \App\Models\Category::where('slug', $slug)->firstOrFail();

        $query = \App\Models\Product::with(['user.profile', 'category'])
            ->where('status', 'approved')
            ->where('category_id', $category->id);

        // filters (same as before)
        if ($request->search) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        if ($request->location) {
            $query->whereHas('user.profile', function ($q) use ($request) {
                $q->where('city', $request->location);
            });
        }

        $products = $query->latest()->paginate(12);


        $featuredVideos = Product::where('status', 'approved')
            ->where('category_id', $category->id)
            ->where('is_featured', 1)
            ->whereNotNull('video')
            ->latest()
            ->get();


        $subcategories = Subcategory::where('category_id', $category->id)
            ->withCount('products')
            ->orderBy('name')
            ->get();

        return view('frontend.product.category', compact('products', 'category', 'featuredVideos', 'subcategories'));
    }

    public function subcategory(Request $request, $category, $subcategory)
    {
        $category = \App\Models\Category::where('slug', $category)
            ->firstOrFail();

        $subcategory = \App\Models\SubCategory::where('category_id', $category->id)
            ->where('slug', $subcategory)
            ->firstOrFail();

        $query = \App\Models\Product::where(
            'sub_category_id',
            $subcategory->id
        );

        // SEARCH
        if ($request->filled('search')) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        // LOCATION
        if ($request->filled('location')) {
            $query->whereHas('user.profile', function ($q) use ($request) {
                $q->where('city', $request->location);
            });
        }

        // PRICE
        if ($request->price === 'under50') {
            $query->where('price', '<', 50000);
        }

        if ($request->price === '50to100') {
            $query->whereBetween('price', [50000, 100000]);
        }

        if ($request->price === '100plus') {
            $query->where('price', '>', 100000);
        }

        $products = $query
            ->latest()
            ->paginate(12)
            ->appends($request->query());

        return view('frontend.product.subcategory', compact(
            'category',
            'subcategory',
            'products'
        ));
    }
}
