<?php

namespace App\Http\Controllers\Frontend;


use App\Http\Controllers\Controller;
use App\Models\BusinessListing;
use App\Models\BusinessReview;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BusinessReviewController extends Controller
{
     public function store(Request $request, BusinessListing $business)
    {
        $rules = [
            'rating' => 'required|integer|min:1|max:5',
            'review' => 'required|min:10|max:1000',
            'title' => 'nullable|max:255',
        ];

        // Guest Validation
        if (!Auth::check()) {
            $rules['guest_name'] = 'required|max:100';
            $rules['guest_email'] = 'required|email|max:255';
            $rules['guest_phone'] = 'nullable|max:30';
        }

        $validated = $request->validate($rules);

        BusinessReview::create([
            'business_listing_id' => $business->id,
            'user_id' => Auth::id(),

            'guest_name' => $validated['guest_name'] ?? null,
            'guest_email' => $validated['guest_email'] ?? null,
            'guest_phone' => $validated['guest_phone'] ?? null,

            'rating' => $validated['rating'],
            'title' => $validated['title'] ?? null,
            'review' => $validated['review'],

            // Guest reviews pending, logged-in reviews approved
            'status' => Auth::check() ? 'approved' : 'pending',

            'approved_at' => Auth::check() ? now() : null,

            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        return back()->with(
            'success',
            Auth::check()
                ? 'Thank you! Your review has been posted.'
                : 'Thank you! Your review has been submitted for approval.'
        );
    }
}
