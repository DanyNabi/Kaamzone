<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\CareerJob;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\JobCategory;
use App\Models\HeroSlider;

class JobsController extends Controller
{
    public function index(Request $request)
    {
        // QUERY

        $query = CareerJob::where(
            'status',
            'active'
        );

        // SEARCH BY KEYWORD

        if ($request->keyword) {

            $query->where(function ($q) use ($request) {

                $q->where(
                    'title',
                    'LIKE',
                    '%' . $request->keyword . '%'
                )
                    ->orWhere(
                        'description',
                        'LIKE',
                        '%' . $request->keyword . '%'
                    );
            });
        }

        // SEARCH BY LOCATION

        if ($request->location) {

            $query->where(
                'location',
                'LIKE',
                '%' . $request->location . '%'
            );
        }

        // JOBS

        $jobs = $query->latest()
            ->paginate(12);

        // STATS

        $totalJobs = CareerJob::count();

        $totalEmployers = User::where(
            'role',
            'employer'
        )->count();

        $totalCandidates = User::where(
            'role',
            'job_seeker'
        )->count();


        $categories = JobCategory::withCount(
            'careerJobs'
        )
            ->latest()
            ->take(6)
            ->get();

        $featuredJobs = CareerJob::with(
            'employer.employerProfile'
        )
            ->where(
                'status',
                'active'
            )
            ->latest()
            ->take(6)
            ->get();

        $sliders = HeroSlider::where('page', 'jobs')
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();

        return view(
            'frontend.jobs.index',
            compact(
                'jobs',
                'totalJobs',
                'totalEmployers',
                'totalCandidates',
                'categories',
                'featuredJobs',
                'sliders'
            )
        );
    }

    public function show($slug)
    {
        $job = CareerJob::where(
            'slug',
            $slug
        )->firstOrFail();

        return view(
            'frontend.jobs.show',
            compact('job')
        );
    }

    // JOB CATEGORY PAGE

    public function category(Request $request, $slug)
    {
        // CATEGORY

        $category = JobCategory::where(
            'slug',
            $slug
        )->firstOrFail();

        // QUERY

        $query = CareerJob::where(
            'job_category_id',
            $category->id
        )
            ->where(
                'status',
                'active'
            );

        // KEYWORD FILTER

        if ($request->keyword) {

            $query->where(
                'title',
                'LIKE',
                '%' . $request->keyword . '%'
            );
        }

        // LOCATION FILTER

        if ($request->location) {

            $query->where(
                'location',
                $request->location
            );
        }

        // JOB TYPE FILTER

        if ($request->job_type) {

            $query->where(
                'job_type',
                $request->job_type
            );
        }

        // ALL JOBS

        $jobs = $query->latest()
            ->paginate(10);

        // SPONSORED JOBS

        $sponsoredJobs = CareerJob::where(
            'job_category_id',
            $category->id
        )
            ->where(
                'status',
                'active'
            )
            ->latest()
            ->take(2)
            ->get();

        // FEATURED JOBS

        $featuredJobs = CareerJob::where(
            'job_category_id',
            $category->id
        )
            ->where(
                'status',
                'active'
            )
            ->latest()
            ->skip(2)
            ->take(2)
            ->get();

        return view(
            'frontend.jobs.category',
            compact(
                'category',
                'jobs',
                'sponsoredJobs',
                'featuredJobs'
            )
        );
    }

    // JOB LISTING PAGE

    public function listing(Request $request)
    {
        // QUERY

        $query = CareerJob::where(
            'status',
            'active'
        );

        // KEYWORD FILTER

        if ($request->keyword) {

            $query->where(function ($q) use ($request) {

                $q->where(
                    'title',
                    'LIKE',
                    '%' . $request->keyword . '%'
                )
                    ->orWhere(
                        'description',
                        'LIKE',
                        '%' . $request->keyword . '%'
                    );
            });
        }

        // LOCATION FILTER

        if ($request->location) {

            $query->where(
                'location',
                'LIKE',
                '%' . $request->location . '%'
            );
        }

        // JOB TYPE FILTER

        if ($request->job_type) {

            $query->where(
                'job_type',
                $request->job_type
            );
        }

        // JOBS

        $jobs = $query->latest()
            ->paginate(10);

        return view(
            'frontend.jobs.listing',
            compact('jobs')
        );
    }
}
