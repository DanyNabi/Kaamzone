<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;
use App\Models\HeroSlider;
use App\Models\SubscriptionModule;
use App\Models\SubscriptionPlan;

class VendorController extends Controller
{
    public function index()
    {
        $categories = \App\Models\Category::withCount([
            'products as products_count' => function ($q) {
                $q->where('status', 'approved');
            }
        ])->take(6)->get();

        // ⭐ Featured Products
        $featuredProducts = Product::with(['user.profile'])
            ->where('status', 'approved')
            ->where('is_featured', 1)
            ->latest()
            ->take(8)
            ->get();

        // 🆕 Latest Products
        $products = Product::with(['user.profile'])
            ->where('status', 'approved')
            ->latest()
            ->take(12)
            ->get();

        // Hero Slider
        $sliders = HeroSlider::where('page', 'buy-sell')
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();
        $buySellModule = SubscriptionModule::where('slug', 'buy-sell')->first();

        $plans = SubscriptionPlan::with('planFeatures.feature')
            ->where('module_id', $buySellModule->id)
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();

             $featuredVideos = Product::where('status', 'approved')
            ->where('is_featured', 1)
            ->whereNotNull('video')
            ->latest()
            ->get();
            
        return view('frontend.vendor.index', compact(
            'categories',
            'featuredProducts',
            'products',
            'sliders',
            'plans',
            'featuredVideos'
        ));
    }
}
