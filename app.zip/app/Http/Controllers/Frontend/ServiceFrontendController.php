<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\ProviderCategory;
use App\Models\ServiceRequest;
use App\Models\User;
use App\Models\HeroSlider;
use App\Models\SubscriptionModule;
use App\Models\SubscriptionPlan;

class ServiceFrontendController extends Controller
{
    public function index()
    {
        // SERVICE CATEGORIES

        $categories = ProviderCategory::where(
            'status',
            1
        )
            ->latest()
            ->take(8)
            ->get();

        // RECENT SERVICES

        $services = ServiceRequest::where(
            'status',
            'open'
        )
            ->latest()
            ->take(6)
            ->get();

        // TOTAL PROVIDERS

        $providers = User::where(
            'role',
            'service_provider'
        )
            ->with([
                'providerProfile',
                'provider_category.category',
                'receivedReviews'
            ])
            ->latest()
            ->take(6)
            ->get();


        $sliders = HeroSlider::where('page', 'services')
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();

        $buySellModule = SubscriptionModule::where('slug', 'business')->first();

        $plans = SubscriptionPlan::with('planFeatures.feature')
            ->where('module_id', $buySellModule->id)
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();

        return view(
            'frontend.services.index',
            compact(
                'categories',
                'services',
                'providers',
                'sliders',
                'plans'
            )
        );
    }

    public function category($slug)
    {
        // CATEGORY

        $category = ProviderCategory::where(
            'slug',
            $slug
        )->firstOrFail();

        // PROVIDERS

        $providers = User::whereHas(
            'provider_category',
            function ($query) use ($category) {

                $query->where(
                    'provider_category_id',
                    $category->id
                );
            }
        )
            ->with([
                'providerProfile',
                'provider_category.category',
                'receivedReviews'
            ])
            ->latest()
            ->paginate(12);

        return view(
            'frontend.services.category',
            compact(
                'category',
                'providers'
            )
        );
    }

    public function listings()
    {
        $categories = ProviderCategory::where(
            'status',
            1
        )
            ->latest()
            ->paginate(12);

        return view(
            'frontend.services.listing',
            compact('categories')
        );
    }
}
