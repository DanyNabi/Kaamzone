<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Auth\Events\Verified;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Http\RedirectResponse;


class VerifyEmailController extends Controller
{
    /**
     * Mark the authenticated user's email address as verified.
     */
    public function __invoke(EmailVerificationRequest $request): RedirectResponse
    {
        $request->fulfill();

        $user = $request->user();

        return match ($user->role) {
            'admin' => redirect('/admin'),
            'vendor' => redirect('/vendors/dashboard'),
            'employer' => redirect('/employer/dashboard'),
            'service_provider' => redirect('/service/dashboard'),
            'customer' => redirect('/customer/dashboard'),
            'business' => redirect('/business/dashboard'),
            'job_seeker' => redirect('/seeker/dashboard'),
            default => redirect('/dashboard'),
        };
    }
}
