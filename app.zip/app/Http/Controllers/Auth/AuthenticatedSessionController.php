<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $request->session()->regenerate();

        $user = Auth::user();

        if ($user->status !== 'approved') {
            Auth::logout();

            return back()->withErrors([
                'email' => 'Your account is not approved yet.',
            ]);
        }


        return match ($user->role) {
            'admin' => redirect('/admin/dashboard'),
            'vendor' => redirect('/vendors/dashboard'),
            'employer' => redirect('/employer/dashboard'),
            'service_provider' => redirect('/service/dashboard'),
            'business' => redirect('/business/dashboard'),
            'customer' => redirect('/customer/dashboard'),
            'job_seeker' => redirect('/seeker/dashboard'),
            default => redirect('/dashboard'),
        };
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
