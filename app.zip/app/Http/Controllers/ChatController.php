<?php

namespace App\Http\Controllers;

use App\Models\Conversation;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Message;

class ChatController extends Controller
{
    public function index()
    {
        return view('chat.widget');
    }

    public function start(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'phone' => 'required'
        ]);

        if (!session()->has('guest_chat_id')) {
            session([
                'guest_chat_id' => Str::uuid()->toString()
            ]);
        }

        $guestId = session('guest_chat_id');

        $conversation = Conversation::firstOrCreate(
            ['guest_id' => $guestId],
            [
                'name' => $request->name,
                'phone' => $request->phone,
                'type' => 'guest'
            ]
        );

        return response()->json([
            'success' => true,
            'conversation_id' => $conversation->id
        ]);
    }

    public function send(Request $request)
    {

        $request->validate([

            'conversation_id' => 'required',

            'message' => 'required'

        ]);

        $message = Message::create([

            'conversation_id' => $request->conversation_id,

            'sender_type' => 'guest',

            'message' => $request->message,

            'sender_id' => null

        ]);

        Conversation::where('id', $request->conversation_id)

            ->update([

                'last_message_at' => now()

            ]);

        return response()->json([

            'success' => true,

            'message' => $message

        ]);
    }

    public function messages($conversation)
    {
        // Admin ke messages ko guest ke liye seen mark karo
        Message::where('conversation_id', $conversation)
            ->where('sender_type', 'admin')
            ->whereNull('seen_at')
            ->update([
                'seen_at' => now()
            ]);

        return Message::where('conversation_id', $conversation)
            ->orderBy('id')
            ->get();
    }

    public function restore()
    {
        $guestId = session('guest_chat_id');

        if (!$guestId) {
            return response()->json([
                'success' => false
            ]);
        }

        $conversation = Conversation::where('guest_id', $guestId)->first();

        if (!$conversation) {
            return response()->json([
                'success' => false
            ]);
        }

        return response()->json([
            'success' => true,
            'conversation' => $conversation
        ]);
    }
}
