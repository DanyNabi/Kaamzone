<?php

namespace App\Http\Controllers\Employer;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionModule;
use App\Models\SubscriptionPlan;
use App\Models\UserSubscription;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\SubscriptionOrder;

class EmployerSubscriptionController extends Controller
{
     public function index()
    {
        $module = SubscriptionModule::where('slug', 'jobs')->first();

        $subscription = UserSubscription::with([
            'module',
            'plan.planFeatures.feature'
        ])
            ->where('user_id', Auth::id())
            ->where('module_id', $module->id)
            ->where('status', 'active')
            ->first();

        return view(
            'employer.subscription.index',
            compact('subscription')
        );
    }

    public function plans()
    {
        $module = SubscriptionModule::where('slug', 'jobs')->first();

        $plans = SubscriptionPlan::with([
            'planFeatures.feature'
        ])
            ->where('module_id', $module->id)
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();

        $currentSubscription = UserSubscription::where(
            'user_id',
            Auth::id()
        )
            ->where('module_id', $module->id)
            ->where('status', 'active')
            ->first();

        return view(
            'employer.subscription.plans',
            compact(
                'plans',
                'currentSubscription'
            )
        );
    }
    public function upgrade($planId)
    {
        $plan = SubscriptionPlan::with('planFeatures.feature')
            ->findOrFail($planId);

        return view(
            'employer.subscription.upgrade',
            compact('plan')
        );
    }

    public function createOrder(Request $request)
    {
        $plan = SubscriptionPlan::findOrFail($request->plan_id);

        $order = SubscriptionOrder::create([

        'order_no' => 'SUB-' . strtoupper(Str::random(8)),

            'user_id' => Auth::id(),

            'module_id' => $plan->module_id,

            'plan_id' => $plan->id,

            'amount' => $plan->price,

            'status' => 'pending',

        ]);

        return redirect()->route(
            'employer.subscription.orders.show',
            $order->id
        );
    }

    public function show($id)
    {
        $order = SubscriptionOrder::with('plan')
            ->where('user_id', Auth::id())
            ->findOrFail($id);

        return view(
            'employer.subscription.show',
            compact('order')
        );
    }

    public function orders()
    {
        $orders = SubscriptionOrder::with('plan')
            ->where('user_id', Auth::id())
            ->latest()
            ->paginate(10);

        return view(
            'employer.subscription.orders',
            compact('orders')
        );
    }

    public function history()
    {
        $orders = SubscriptionOrder::with('plan')
            ->where('user_id', Auth::id())
            ->where('status', 'approved')
            ->latest()
            ->paginate(10);

        return view(
            'employer.subscription.history',
            compact('orders')
        );
    }

    public function uploadProof(Request $request, $id)
    {
        $request->validate([
            'payment_proof' => 'required|image|mimes:jpg,jpeg,png|max:2048'
        ]);

        $order = SubscriptionOrder::where('user_id', Auth::id())
            ->findOrFail($id);

        if ($request->hasFile('payment_proof')) {

            $image = $request->file('payment_proof');

            $name = time() . '.' . $image->getClientOriginalExtension();

            $image->move(
                public_path('uploads/payment-proofs'),
                $name
            );

            $order->payment_proof = $name;

            $order->save();
        }

        return back()->with(
            'success',
            'Payment proof uploaded successfully.'
        );
    }
}
