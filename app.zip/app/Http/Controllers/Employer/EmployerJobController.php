<?php

namespace App\Http\Controllers\Employer;

use App\Http\Controllers\Controller;
use App\Models\CareerJob;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use App\Models\JobApplication;
use App\Models\JobCategory;
use App\Services\SubscriptionService;

class EmployerJobController extends Controller
{
    // JOBS LIST

    public function index()
    {
        $jobs = CareerJob::where(
            'user_id',
            Auth::id()
        )
            ->latest()
            ->paginate(10);

        return view(
            'employer.jobs.index',
            compact('jobs')
        );
    }

    // CREATE PAGE

    public function create()
    {
        $profile = Auth::user()
            ->employerProfile;

        $categories = JobCategory::latest()
            ->get();

        return view(
            'employer.jobs.create',
            compact('profile', 'categories')
        );
    }

    // STORE JOB

    public function store(Request $request)
    {
        // Active Jobs Limit

        $currentJobs = CareerJob::where('user_id', Auth::id())
            ->whereIn('status', ['active', 'pending'])
            ->count();

        $limit = SubscriptionService::getLimit(
            Auth::user(),
            'jobs',
            'active-jobs'
        );

        if (
            $limit !== null &&
            $limit !== PHP_INT_MAX &&
            $currentJobs >= $limit
        ) {
            return back()
                ->withInput()
                ->with(
                    'error',
                    'You have reached your active jobs limit. Please upgrade your subscription.'
                );
        }

        // Featured Jobs Limit

        $featuredLimit = SubscriptionService::getLimit(
            Auth::user(),
            'jobs',
            'featured-jobs'
        );

        $currentFeatured = CareerJob::where('user_id', Auth::id())
            ->where('is_featured', 1)
            ->whereIn('status', ['active', 'pending'])
            ->count();

        $isFeatured = false;

        if (
            $request->has('is_featured') &&
            (
                $featuredLimit === PHP_INT_MAX ||
                $currentFeatured < $featuredLimit
            )
        ) {
            $isFeatured = true;
        }

        // Job Duration

        $duration = SubscriptionService::getLimit(
            Auth::user(),
            'jobs',
            'job-duration'
        );

        $duration = $duration ?: 30;

        // Validation

        $request->validate([

            'title' => 'required',

            'company_name' => 'required',

            'description' => 'required',

            'job_category_id' => 'required',

        ]);

        CareerJob::create([

            'user_id' => Auth::id(),

            'title' => $request->title,

            'slug' => Str::slug($request->title) . '-' . time(),

            'company_name' => $request->company_name,

            'job_category_id' => $request->job_category_id,

            'location' => $request->location,

            'job_type' => $request->job_type,

            'salary' => $request->salary,

            'experience' => $request->experience,

            'description' => $request->description,

            'status' => 'active',

            'is_featured' => $isFeatured,

            'expires_at' => now()->addDays($duration),

        ]);

        return redirect()
            ->route('employer.jobs')
            ->with(
                'success',
                'Job posted successfully.'
            );
    }

    // EDIT PAGE

    public function edit($id)
    {
        $job = CareerJob::findOrFail($id);

        $categories = JobCategory::latest()
            ->get();

        return view(
            'employer.jobs.edit',
            compact(
                'job',
                'categories'
            )
        );
    }

    // UPDATE JOB

    public function update(Request $request, $id)
    {
        $job = CareerJob::where(
            'user_id',
            Auth::id()
        )->findOrFail($id);

        $request->validate([

            'title' => 'required',

            'company_name' => 'required',

            'description' => 'required'

        ]);

        $job->update([

            'title' => $request->title,

            'company_name' =>
            $request->company_name,

            'job_category_id' =>
            $request->job_category_id,

            'location' =>
            $request->location,

            'job_type' =>
            $request->job_type,

            'salary' =>
            $request->salary,

            'experience' =>
            $request->experience,

            'description' =>
            $request->description,

        ]);

        return redirect()
            ->route('employer.jobs')
            ->with(
                'success',
                'Job updated successfully.'
            );
    }

    // DELETE JOB

    public function destroy($id)
    {
        $job = CareerJob::where(
            'user_id',
            Auth::id()
        )->findOrFail($id);

        $job->delete();

        return back()->with(
            'success',
            'Job deleted successfully.'
        );
    }

    // VIEW APPLICATIONS

    public function applications($id)
    {
        $job = CareerJob::where(
            'user_id',
            Auth::id()
        )
            ->with('applications.applicant')
            ->findOrFail($id);

        return view(
            'employer.jobs.applications',
            compact('job')
        );
    }

    // ACCEPT APPLICATION

    public function acceptApplication($id)
    {
        $application = JobApplication::findOrFail($id);

        $application->update([

            'status' => 'accepted'

        ]);

        return back()->with(
            'success',
            'Candidate accepted.'
        );
    }

    // REJECT APPLICATION

    public function rejectApplication($id)
    {
        $application = JobApplication::findOrFail($id);

        $application->update([

            'status' => 'rejected'

        ]);

        return back()->with(
            'success',
            'Candidate rejected.'
        );
    }

    public function showApplication($id)
    {
        $application = JobApplication::with([

            'applicant',

            'job'

        ])->findOrFail($id);

        return view(
            'employer.jobs.show_application',
            compact('application')
        );
    }


    // CLOSE JOB

    public function closeJob($id)
    {
        $job = CareerJob::where(
            'user_id',
            Auth::id()
        )->findOrFail($id);

        $job->update([

            'status' => 'closed'

        ]);

        return back()->with(
            'success',
            'Job closed successfully.'
        );
    }

    // REOPEN JOB

    public function reopenJob($id)
    {
        $job = CareerJob::where(
            'user_id',
            Auth::id()
        )->findOrFail($id);

        $job->update([

            'status' => 'active'

        ]);

        return back()->with(
            'success',
            'Job reopened successfully.'
        );
    }

    public function shortlistApplication($id)
    {
        $application = JobApplication::findOrFail($id);

        $application->update([

            'status' => 'shortlisted'

        ]);

        return back()->with(
            'success',
            'Candidate shortlisted.'
        );
    }
}
