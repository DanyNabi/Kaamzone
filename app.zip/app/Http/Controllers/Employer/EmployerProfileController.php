<?php

namespace App\Http\Controllers\Employer;

use App\Http\Controllers\Controller;
use App\Models\EmployerProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class EmployerProfileController extends Controller
{
    public function edit()
    {
        $profile = EmployerProfile::firstOrCreate([

            'user_id' => Auth::id()

        ]);

        return view(
            'employer.company-profile.edit',
            compact('profile')
        );
    }

    public function update(Request $request)
    {
        $profile = EmployerProfile::firstOrCreate([

            'user_id' => Auth::id()

        ]);

        // LOGO

        if ($request->hasFile('company_logo')) {

            $logo = $request->file('company_logo');

            $logoName = time() . '.' .
                $logo->getClientOriginalExtension();

            $logo->move(
                public_path('uploads/employers'),
                $logoName
            );

            $profile->company_logo =
                'uploads/employers/' . $logoName;
        }

        // SAVE DATA

        $profile->company_name =
            $request->company_name;

        $profile->website =
            $request->website;

        $profile->industry =
            $request->industry;

        $profile->company_size =
            $request->company_size;

        $profile->location =
            $request->location;

        $profile->about =
            $request->about;

        $profile->facebook =
            $request->facebook;

        $profile->linkedin =
            $request->linkedin;

        $profile->twitter =
            $request->twitter;

        $profile->save();

        return back()->with(
            'success',
            'Profile updated successfully.'
        );
    }
}
