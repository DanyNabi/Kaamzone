<?php

namespace App\Http\Controllers;

use App\Models\User;

class ProviderController extends Controller
{
    public function show($id)
    {
        $provider = User::with([

            'providerProfile',

            'provider_category.category',

            'receivedReviews.user'

        ])->findOrFail($id);

        // AVERAGE RATING

        $averageRating = $provider
            ->receivedReviews()
            ->avg('rating');

        return view(
            'frontend.services.show',
            compact(
                'provider',
                'averageRating'
            )
        );
    }
}