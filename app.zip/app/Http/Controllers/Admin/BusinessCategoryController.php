<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BusinessCategory;

class BusinessCategoryController extends Controller
{
  public function index()
    {
        $categories = BusinessCategory::latest()->paginate(10);

        return view('admin.business-categories.index', compact('categories'));
    }

    // STORE
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required'
        ]);

        BusinessCategory::create([
            'name' => $request->name,
            'description' => $request->description
        ]);

        return back()->with('success', 'Category added');
    }

    // UPDATE
    public function update(Request $request, $id)
    {
        $category = BusinessCategory::findOrFail($id);

        $category->update([
            'name' => $request->name,
            'description' => $request->description
        ]);

        return back()->with('success', 'Category updated');
    }

    // DELETE
    public function destroy($id)
    {
        BusinessCategory::findOrFail($id)->delete();

        return back()->with('success', 'Category deleted');
    }
}
