<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CategoryRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; 

class CategoryRequestController extends Controller
{
    public function index()
    {
        $requests = CategoryRequest::with('user')
            ->latest()
            ->paginate(20);

        return view(
            'admin.category-requests.index',
            compact('requests')
        );
    }


    public function show($id)
    {
        $categoryRequest = CategoryRequest::with('user')
            ->findOrFail($id);

        return view(
            'admin.category-requests.show',
            compact('categoryRequest')
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Approve Request
    |--------------------------------------------------------------------------
    */

    public function approve($id)
    {
        $categoryRequest = CategoryRequest::findOrFail($id);

        // Already processed
        if ($categoryRequest->status !== 'pending') {

            return back()->with(
                'error',
                'This request has already been processed.'
            );
        }


        $categoryRequest->update([
            'status' => 'approved',
            'reviewed_by' => Auth::id(),
            'reviewed_at' => now(),
        ]);


        return redirect()
            ->route('admin.category-requests.show', $categoryRequest->id)
            ->with(
                'success',
                'Category request approved successfully.'
            );
    }


    /*
    |--------------------------------------------------------------------------
    | Decline Request
    |--------------------------------------------------------------------------
    */

    public function decline(Request $request, $id)
    {
        $categoryRequest = CategoryRequest::findOrFail($id);


        $request->validate([
            'admin_note' => [
                'required',
                'string',
                'max:2000',
            ],
        ]);


        // Already processed
        if ($categoryRequest->status !== 'pending') {

            return back()->with(
                'error',
                'This request has already been processed.'
            );
        }


        $categoryRequest->update([
            'status' => 'declined',
            'admin_note' => $request->admin_note,
            'reviewed_by' => Auth::id(),
            'reviewed_at' => now(),
        ]);


        return redirect()
            ->route('admin.category-requests.show', $categoryRequest->id)
            ->with(
                'success',
                'Category request declined successfully.'
            );
    }
}