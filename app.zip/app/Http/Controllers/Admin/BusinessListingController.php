<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BusinessListing;
use App\Models\BusinessCategory;

class BusinessListingController extends Controller
{
    // ALL LISTINGS
    public function index(Request $request)
    {
        // QUERY
        $query = BusinessListing::with(
            'category',
            'user'
        );

        // CATEGORY FILTER
        if ($request->category) {

            $category = BusinessCategory::where(
                'slug',
                $request->category
            )->first();

            if ($category) {

                $query->where(
                    'category_id',
                    $category->id
                );
            }
        }

        // STATUS FILTER
        if ($request->status && $request->status != 'all') {

            $query->where(
                'status',
                $request->status
            );
        }

        // LISTINGS
        $listings = $query
            ->latest()
            ->paginate(15);

        // CATEGORIES
        $categories = BusinessCategory::latest()->get();

        return view(
            'admin.business-listings.index',
            compact(
                'listings',
                'categories'
            )
        );
    }

    // APPROVE
    public function approve($id)
    {
        $listing = BusinessListing::findOrFail($id);

        $listing->status = 'approved';

        $listing->save();

        return redirect()
            ->back()
            ->with(
                'success',
                'Business Listing Approved Successfully'
            );
    }

    // REJECT
    public function reject($id)
    {
        $listing = BusinessListing::findOrFail($id);

        $listing->status = 'rejected';

        $listing->save();

        return redirect()
            ->back()
            ->with(
                'success',
                'Business Listing Rejected Successfully'
            );
    }
}
