<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\HeroSlider;
use Illuminate\Support\Facades\File;

class HeroSliderController extends Controller
{
    public function index()
    {
        $sliders = HeroSlider::orderBy('page')
            ->orderBy('sort_order')
            ->paginate(10);

        return view(
            'admin.hero-sliders.index',
            compact('sliders')
        );
    }
   
        public function store(Request $request)
{
    $request->validate([
        'page' => 'required',
        'heading' => 'required',
        'sort_order' => 'required|integer',
        'status' => 'required|boolean',
        'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg,webp|max:8192',
    ]);

    // Upload Image (Exactly like Products)
    $imageName = null;

    if ($request->hasFile('image')) {

        $image = $request->file('image');

        $imageName = time() . '.' . $image->getClientOriginalExtension();

        $image->move(
             $_SERVER['DOCUMENT_ROOT'].'/uploads/hero-sliders',
            $imageName
        );
    }

    HeroSlider::create([

        'page' => $request->page,

        'badge' => $request->badge,

        'heading' => $request->heading,

        'description' => $request->description,

        'button1_text' => $request->button1_text,
        'button1_link' => $request->button1_link,

        'button2_text' => $request->button2_text,
        'button2_link' => $request->button2_link,

        // Sirf filename save hoga
        'image' => $imageName,

        'sort_order' => $request->sort_order,

        'status' => $request->status,
    ]);

    return back()->with(
        'success',
        'Hero Slider Added Successfully.'
    );
}
    
 public function update(Request $request, $id)
    {
        $slider = HeroSlider::findOrFail($id);

        $request->validate([

            'page' => 'required',

            'heading' => 'required',

            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:8192',

        ]);

        if ($request->hasFile('image')) {

            // Delete old image
   if (
    $slider->image &&
    file_exists($_SERVER['DOCUMENT_ROOT'] . '/uploads/hero-sliders/' . $slider->image)
) {
    unlink($_SERVER['DOCUMENT_ROOT'] . '/uploads/hero-sliders/' . $slider->image);
}

    $image = $request->file('image');

    $imageName = time() . '.' . $image->getClientOriginalExtension();

    $image->move(
         $_SERVER['DOCUMENT_ROOT'].'/uploads/hero-sliders',
        $imageName
    );

    $slider->image = $imageName;
        }

        $slider->page = $request->page;

        $slider->badge = $request->badge;

        $slider->heading = $request->heading;

        $slider->description = $request->description;

        $slider->button1_text = $request->button1_text;

        $slider->button1_link = $request->button1_link;

        $slider->button2_text = $request->button2_text;

        $slider->button2_link = $request->button2_link;

        $slider->sort_order = $request->sort_order;

        $slider->status = $request->status;

        $slider->save();

        return back()->with(
            'success',
            'Hero Slider Updated Successfully'
        );
    }
    public function destroy($id)
    {
        $slider = HeroSlider::findOrFail($id);

        if (
            $slider->image &&
            file_exists(public_path($slider->image))
        ) {

            unlink(public_path($slider->image));
        }

        $slider->delete();

        return back()->with(
            'success',
            'Hero Slider Deleted Successfully'
        );
    }
}
