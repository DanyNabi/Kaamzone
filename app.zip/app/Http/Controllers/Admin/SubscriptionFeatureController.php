<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\SubscriptionFeature;
use App\Models\SubscriptionModule;


class SubscriptionFeatureController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $features = SubscriptionFeature::with('module')
            ->latest()
            ->get();

        $modules = SubscriptionModule::where('status', 1)->get();

        return view('admin.subscription-features.index', compact(
            'features',
            'modules'
        ));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'module_id' => 'required|exists:subscription_modules,id',
            'name'      => 'required|max:255',
            'slug'      => 'required|unique:subscription_features,slug',
            'type'      => 'required|in:number,boolean,text',
            'status'    => 'required|boolean',
        ]);

        SubscriptionFeature::create([
            'module_id' => $request->module_id,
            'name'      => $request->name,
            'slug'      => Str::slug($request->slug),
            'type'      => $request->type,
            'status'    => $request->status,
        ]);

        return back()->with('success', 'Feature added successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        return SubscriptionFeature::findOrFail($id);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $feature = SubscriptionFeature::findOrFail($id);

        $request->validate([
            'module_id' => 'required|exists:subscription_modules,id',
            'name'      => 'required|max:255',
            'slug'      => 'required|unique:subscription_features,slug,' . $feature->id,
            'type'      => 'required|in:number,boolean,text',
            'status'    => 'required|boolean',
        ]);

        $feature->update([
            'module_id' => $request->module_id,
            'name'      => $request->name,
            'slug'      => Str::slug($request->slug),
            'type'      => $request->type,
            'status'    => $request->status,
        ]);

        return back()->with('success', 'Feature updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        SubscriptionFeature::findOrFail($id)->delete();

        return back()->with('success', 'Feature deleted successfully.');
    }
}
