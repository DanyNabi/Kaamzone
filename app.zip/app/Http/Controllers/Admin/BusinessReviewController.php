<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BusinessReview;

class BusinessReviewController extends Controller
{
    public function index()
    {
        $reviews = BusinessReview::with('business')
            ->latest()
            ->paginate(20);

        return view(
            'admin.business-reviews.index',
            compact('reviews')
        );
    }

    public function approve(BusinessReview $review)
    {
        $review->update([
            'status' => 'approved',
            'approved_at' => now(),
        ]);

        return back()->with(
            'success',
            'Review approved successfully.'
        );
    }

    public function reject(BusinessReview $review)
    {
        $review->update([
            'status' => 'rejected',
        ]);

        return back()->with(
            'success',
            'Review rejected.'
        );
    }
    public function destroy(BusinessReview $review)
    {
        $review->delete();

        return back()->with(
            'success',
            'Review deleted.'
        );
    }
}
