<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProviderCategory;
use App\Models\ProviderSubCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;


class ProviderSubCategoryController extends Controller
{
    public function index()
    {
        $categories = ProviderCategory::all();

        $subCategories = ProviderSubCategory::with('category')
            ->latest()
            ->get();

        return view(
            'admin.provider-subcategories.index',
            compact(
                'categories',
                'subCategories'
            )
        );
    }

    public function store(Request $request)
    {
        $request->validate([
            'provider_category_id' => 'required',
            'name' => 'required'
        ]);

        ProviderSubCategory::create([
            'provider_category_id' => $request->provider_category_id,
            'name' => $request->name,
            'slug' => Str::slug($request->name)
        ]);

        return back()->with(
            'success',
            'Provider Sub Category Added'
        );
    }

    public function update(Request $request, $id)
    {
        $subCategory = ProviderSubCategory::findOrFail($id);

        $subCategory->update([
            'provider_category_id' => $request->provider_category_id,
            'name' => $request->name,
            'slug' => Str::slug($request->name),
        ]);

        return back()->with(
            'success',
            'Updated Successfully'
        );
    }


    public function destroy($id)
    {
        ProviderSubCategory::findOrFail($id)
            ->delete();

        return back()->with(
            'success',
            'Deleted Successfully'
        );
    }

    public function edit($id)
    {
        $subCategory = ProviderSubCategory::findOrFail($id);

        $categories = ProviderCategory::all();

        return view(
            'admin.provider-subcategories.edit',
            compact(
                'subCategory',
                'categories'
            )
        );
    }
}
