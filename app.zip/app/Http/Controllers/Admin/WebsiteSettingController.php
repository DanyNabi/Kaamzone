<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\WebsiteSetting;

class WebsiteSettingController extends Controller
{
    public function index()
    {
        $setting = WebsiteSetting::first();

        return view(
            'admin.website-settings.index',
            compact('setting')
        );
    }

    public function update(Request $request)
    {
        $request->validate([
            'site_name' => 'nullable|string|max:255',
            'tagline' => 'nullable|string|max:255',

            'desktop_logo_width' => 'required|integer',
            'mobile_logo_width' => 'required|integer',

            'logo' => 'nullable|image|mimes:jpg,jpeg,png,webp,svg|max:10240',
            'dark_logo' => 'nullable|image|mimes:jpg,jpeg,png,webp,svg|max:10240',
            'favicon' => 'nullable|image|mimes:png,ico,webp|max:2048',
        ]);

        $setting = WebsiteSetting::first();

        if (!$setting) {
            $setting = new WebsiteSetting();
        }

        // General

        $setting->site_name = $request->site_name;
        $setting->tagline = $request->tagline;

        $setting->desktop_logo_width = $request->desktop_logo_width;
        $setting->mobile_logo_width = $request->mobile_logo_width;

        // Upload Folder

        $destination = $_SERVER['DOCUMENT_ROOT'] . '/uploads/settings';

        if (!file_exists($destination)) {
            mkdir($destination, 0755, true);
        }

        // Logo

        if ($request->hasFile('logo')) {

            if (
                $setting->logo &&
                file_exists($_SERVER['DOCUMENT_ROOT'] . '/' . $setting->logo)
            ) {
                unlink($_SERVER['DOCUMENT_ROOT'] . '/' . $setting->logo);
            }

            $file = $request->file('logo');

            $name = time() . '_logo.' . $file->getClientOriginalExtension();

            $file->move($destination, $name);

            // Database mein relative path save karo
            $setting->logo = 'uploads/settings/' . $name;
        }

        // Dark Logo

        if ($request->hasFile('dark_logo')) {

            if (
                $setting->dark_logo &&
                file_exists($_SERVER['DOCUMENT_ROOT'] . '/' . $setting->dark_logo)
            ) {
                unlink($_SERVER['DOCUMENT_ROOT'] . '/' . $setting->dark_logo);
            }

            $file = $request->file('dark_logo');

            $name = time() . '_dark_logo.' . $file->getClientOriginalExtension();

            $file->move($destination, $name);

            $setting->dark_logo = 'uploads/settings/' . $name;
        }

        // Favicon

        if ($request->hasFile('favicon')) {

            if (
                $setting->favicon &&
                file_exists($_SERVER['DOCUMENT_ROOT'] . '/' . $setting->favicon)
            ) {
                unlink($_SERVER['DOCUMENT_ROOT'] . '/' . $setting->favicon);
            }

            $file = $request->file('favicon');

            $name = time() . '_favicon.' . $file->getClientOriginalExtension();

            $file->move($destination, $name);

            $setting->favicon = 'uploads/settings/' . $name;
        }

        $setting->save();

        return back()->with(
            'success',
            'Website settings updated successfully.'
        );
    }
}
