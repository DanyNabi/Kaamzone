<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SubscriptionPlan;
use App\Models\SubscriptionModule;
use Illuminate\Support\Str;


class SubscriptionPlanController extends Controller
{
    public function index()
    {
        $plans = SubscriptionPlan::with('module')
            ->orderBy('module_id')
            ->orderBy('sort_order')
            ->get();

        return view('admin.subscriptions.plans.index', compact('plans'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'module_id'     => 'required|exists:subscription_modules,id',
            'name'          => 'required|string|max:255',
            'price'         => 'required|numeric|min:0',
            'billing_cycle' => 'required',
            'duration'      => 'required|integer|min:1',
            'trial_days'    => 'nullable|integer|min:0',
            'sort_order'    => 'nullable|integer|min:0',
        ]);

        SubscriptionPlan::create([

            'module_id'     => $request->module_id,

            'name'          => $request->name,

            'slug'          => $request->slug
                ? Str::slug($request->slug)
                : Str::slug($request->name),

            'price'         => $request->price,

            'billing_cycle' => $request->billing_cycle,

            'duration'      => $request->duration,

            'trial_days'    => $request->trial_days ?? 0,

            'description'   => $request->description,

            'badge'         => $request->badge,

            'color'         => $request->color,

            'is_popular'    => $request->has('is_popular'),

            'is_featured'   => $request->has('is_featured'),

            'status'        => $request->has('status'),

            'sort_order'    => $request->sort_order ?? 0,

        ]);

        return redirect()
            ->route('admin.subscription-plans')
            ->with('success', 'Subscription Plan created successfully.');
    }

    public function edit(SubscriptionPlan $plan)
    {
        return view('admin.subscriptions.plans.edit', compact('plan'));
    }

    public function update(Request $request, SubscriptionPlan $plan)
    {
        $request->validate([
            'price'          => 'required|numeric|min:0',
            'billing_cycle'  => 'required|in:monthly,quarterly,yearly,lifetime',
            'duration'       => 'nullable|integer|min:0',
            'trial_days'     => 'nullable|integer|min:0',
            'description'    => 'nullable|string',
            'status'         => 'required|boolean',
            'sort_order'     => 'required|integer|min:0',
        ]);

        $plan->update([
            'price'          => $request->price,
            'billing_cycle'  => $request->billing_cycle,
            'duration'       => $request->billing_cycle == 'lifetime' ? null : $request->duration,
            'trial_days'     => $request->trial_days,
            'description'    => $request->description,
            'is_popular'     => $request->has('is_popular'),
            'is_featured'    => $request->has('is_featured'),
            'status'         => $request->status,
            'sort_order'     => $request->sort_order,
        ]);

        return redirect()
            ->route('admin.subscription-plans')
            ->with('success', 'Plan updated successfully.');
    }

    public function create()
    {
        $modules = SubscriptionModule::where('status', 1)
            ->orderBy('name')
            ->get();

        return view(
            'admin.subscriptions.plans.create',
            compact('modules')
        );
    }
}
