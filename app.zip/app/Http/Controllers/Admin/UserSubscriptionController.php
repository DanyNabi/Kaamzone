<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionModule;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Models\UserSubscription;
use Illuminate\Http\Request;

class UserSubscriptionController extends Controller
{
    public function index()
    {
        $users = User::orderBy('name')->get();

        $modules = SubscriptionModule::where('status', 1)->get();

        $subscriptions = UserSubscription::with([
            'user',
            'module',
            'plan'
        ])
        ->latest()
        ->paginate(20);

        return view(
            'admin.subscriptions.users.index',
            compact(
                'users',
                'modules',
                'subscriptions'
            )
        );
    }

    public function getPlans($moduleId)
    {
        return SubscriptionPlan::where('module_id', $moduleId)
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();
    }

    public function store(Request $request)
    {
        $request->validate([
            'user_id'   => 'required|exists:users,id',
            'module_id' => 'required|exists:subscription_modules,id',
            'plan_id'   => 'required|exists:subscription_plans,id',
        ]);

        $plan = SubscriptionPlan::findOrFail($request->plan_id);

        // Purani active subscription expire karo
        UserSubscription::where('user_id', $request->user_id)
            ->where('module_id', $request->module_id)
            ->where('status', 'active')
            ->update([
                'status' => 'expired',
            ]);

        UserSubscription::create([
            'user_id'    => $request->user_id,
            'module_id'  => $request->module_id,
            'plan_id'    => $plan->id,
            'starts_at'  => now(),
            'expires_at' => $plan->billing_cycle === 'lifetime'
                ? null
                : now()->addDays($plan->duration),
            'status'     => 'active',
        ]);

        return back()->with(
            'success',
            'Subscription assigned successfully.'
        );
    }
}