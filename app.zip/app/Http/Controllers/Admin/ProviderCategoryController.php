<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProviderCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProviderCategoryController extends Controller
{
    public function index()
    {
        $categories = ProviderCategory::latest()->get();

        return view(
            'admin.provider-categories.index',
            compact('categories')
        );
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:provider_categories,name'
        ]);

        ProviderCategory::create([

            'name' => $request->name,

            'slug' => Str::slug($request->name)

        ]);

        return back()->with(
            'success',
            'Provider category added successfully.'
        );
    }


    public function edit($id)
    {
        $category = ProviderCategory::findOrFail($id);

        return view(
            'admin.provider-categories.edit',
            compact('category')
        );
    }

    public function update(Request $request, $id)
    {
        $request->validate([

            'name' => 'required|unique:provider_categories,name,' . $id

        ]);

        $category = ProviderCategory::findOrFail($id);

        $category->update([

            'name' => $request->name,

            'slug' => Str::slug($request->name),

            'status' => $request->status

        ]);

        return redirect()
            ->route('admin.provider-categories')
            ->with(
                'success',
                'Provider category updated successfully.'
            );
    }

    public function destroy($id)
    {
        $category = ProviderCategory::findOrFail($id);

        $category->delete();

        return back()->with(
            'success',
            'Provider category deleted successfully.'
        );
    }
}
