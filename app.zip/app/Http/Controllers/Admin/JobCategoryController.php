<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\JobCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class JobCategoryController extends Controller
{
    // INDEX

    public function index()
    {
        $categories = JobCategory::latest()
            ->paginate(10);

        return view(
            'admin.job-categories.index',
            compact('categories')
        );
    }

    // STORE

    public function store(Request $request)
    {
        $request->validate([

            'name' => 'required'

        ]);

        JobCategory::create([

            'name' => $request->name,

            'slug' => Str::slug(
                $request->name
            ),

            'icon' => $request->icon

        ]);

        return back()->with(
            'success',
            'Category added successfully.'
        );
    }

    // UPDATE

    public function update(Request $request, $id)
    {
        $category = JobCategory::findOrFail($id);

        $category->update([

            'name' => $request->name,

            'slug' => Str::slug(
                $request->name
            ),

            'icon' => $request->icon

        ]);

        return back()->with(
            'success',
            'Category updated successfully.'
        );
    }

    // DELETE

    public function destroy($id)
    {
        JobCategory::findOrFail($id)
            ->delete();

        return back()->with(
            'success',
            'Category deleted successfully.'
        );
    }
}