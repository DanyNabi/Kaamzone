<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionFeature;
use App\Models\SubscriptionPlan;
use App\Models\SubscriptionPlanFeature;
use Illuminate\Http\Request;

class PlanConfigurationController extends Controller
{
    public function index(SubscriptionPlan $plan)
    {
        $features = SubscriptionFeature::where('module_id', $plan->module_id)
            ->orderBy('feature_group')
            ->orderBy('name')
            ->get();

        $planFeatures = SubscriptionPlanFeature::where('plan_id', $plan->id)
            ->get()
            ->keyBy('feature_id');

        return view(
            'admin.subscriptions.configure.index',
            compact(
                'plan',
                'features',
                'planFeatures'
            )
        );
    }

    public function store(Request $request, SubscriptionPlan $plan)
    {
        foreach ($request->features ?? [] as $featureId => $value) {

            $feature = SubscriptionFeature::find($featureId);

            if (!$feature) {
                continue;
            }

            $isUnlimited = isset($request->unlimited[$featureId]);

            if ($feature->type == 'boolean') {
                $value = isset($request->features[$featureId]) ? 1 : 0;
            }

            SubscriptionPlanFeature::updateOrCreate(

                [
                    'plan_id' => $plan->id,
                    'feature_id' => $featureId,
                ],

                [
                    'value' => $value,
                    'is_unlimited' => $isUnlimited,
                ]

            );
        }

        return redirect()
            ->back()
            ->with('success', 'Configuration updated successfully.');
    }
}
