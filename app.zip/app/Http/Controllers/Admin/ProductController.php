<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $query = Product::with(['user', 'category']);

        // 🎯 CATEGORY FILTER
        if ($request->category) {
            $query->where('category_id', $request->category);
        }

        // 🎯 STATUS FILTER
        if ($request->status && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        $products = $query->latest()->paginate(10);

        $categories = Category::all();

        return view('admin.products.index', compact('products', 'categories'));
    }

    // ✅ Approve
    public function approve($id)
    {
        $product = Product::findOrFail($id);
        $product->update(['status' => 'approved']);

        return back()->with('success', 'Product approved');
    }

    // ❌ Reject
    public function reject($id)
    {
        $product = Product::findOrFail($id);
        $product->update(['status' => 'rejected']);

        return back()->with('success', 'Product rejected');
    }
}
