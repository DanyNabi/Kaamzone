<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Message;
use App\Models\Conversation;
use Illuminate\Support\Facades\Auth;


class AdminChatController extends Controller
{
    public function index()
    {
        $conversations = Conversation::latest('last_message_at')->get();

        return view('admin.chat.index', compact('conversations'));
    }

    public function show(Conversation $conversation)
    {
        // Guest ke unread messages ko seen mark karo
        Message::where('conversation_id', $conversation->id)
            ->whereNull('seen_at')
            ->where('sender_type', 'guest')
            ->update([
                'seen_at' => now()
            ]);

        $messages = $conversation->messages()
            ->orderBy('id')
            ->get();

        $conversations = Conversation::latest('last_message_at')->get();

        return view('admin.chat.index', compact(
            'conversation',
            'messages',
            'conversations'
        ));
    }
    public function send(Request $request)
    {
        $request->validate([
            'conversation_id' => 'required|exists:conversations,id',
            'message' => 'required'
        ]);

        $message = Message::create([
            'conversation_id' => $request->conversation_id,
            'sender_id' => Auth::id(),
            'sender_type' => 'admin',
            'message' => $request->message,
        ]);

        Conversation::where('id', $request->conversation_id)
            ->update([
                'last_message_at' => now()
            ]);

        return response()->json([
            'success' => true,
            'message' => $message
        ]);
    }

    public function messages(Conversation $conversation)
    {
        Message::where('conversation_id', $conversation->id)
            ->whereNull('seen_at')
            ->where('sender_type', 'guest')
            ->update([
                'seen_at' => now()
            ]);

        return $conversation->messages()
            ->orderBy('id')
            ->get();
    }

    public function conversationList()
    {
        $conversations = Conversation::withCount([
            'messages as unread' => function ($q) {
                $q->where('sender_type', 'guest')
                    ->whereNull('seen_at');
            }
        ])
            ->latest('last_message_at')
            ->get();

        return response()->json($conversations);
    }
}
