<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SubscriptionOrder;
use Illuminate\Support\Facades\DB;
use App\Models\UserSubscription;
use App\Services\SubscriptionActivationService;


class SubscriptionOrderController extends Controller
{
    public function index()
    {
        $orders = SubscriptionOrder::with([
            'user',
            'module',
            'plan'
        ])
            ->latest()
            ->paginate(20);

        return view(
            'admin.subscription-orders.index',
            compact('orders')
        );
    }

    public function show(SubscriptionOrder $order)
    {
        $order->load([
            'user',
            'module',
            'plan'
        ]);

        return view(
            'admin.subscription-orders.show',
            compact('order')
        );
    }

    public function approve(SubscriptionOrder $order)
    {
        if ($order->status == 'completed') {

            return back()->with(
                'error',
                'Order already completed.'
            );
        }

        SubscriptionActivationService::activate($order);

        return redirect()
            ->route('admin.subscription-orders')
            ->with(
                'success',
                'Subscription activated successfully.'
            );
    }

    public function reject(SubscriptionOrder $order)
    {
        if ($order->status == 'completed') {

            return back()->with(
                'error',
                'Completed orders cannot be rejected.'
            );
        }

        $order->update([

            'status' => 'cancelled',

            'payment_status' => 'failed',

        ]);

        return redirect()
            ->route('admin.subscription-orders')
            ->with(
                'success',
                'Order rejected successfully.'
            );
    }
}
