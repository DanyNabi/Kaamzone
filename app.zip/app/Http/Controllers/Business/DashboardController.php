<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\BusinessListing;
use Illuminate\Validation\Rule;
use App\Models\UserProfile;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $userId = Auth::id();

        // TOTAL
        $total = BusinessListing::where('user_id', $userId)->count();

        // PENDING
        $pending = BusinessListing::where('user_id', $userId)
            ->where('status', 'pending')
            ->count();

        // APPROVED
        $approved = BusinessListing::where('user_id', $userId)
            ->where('status', 'approved')
            ->count();

        // REJECTED
        $rejected = BusinessListing::where('user_id', $userId)
            ->where('status', 'rejected')
            ->count();

        // RECENT LISTINGS
        $listings = BusinessListing::where('user_id', $userId)
            ->latest()
            ->take(5)
            ->get();

        return view('business.dashboard', compact(
            'total',
            'pending',
            'approved',
            'rejected',
            'listings'
        ));
    }
    public function updateProfile(Request $request)
    {
        $user = Auth::user();

        // ✅ Validation (email unique fix)
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'email',
                Rule::unique('users')->ignore($user->id),
            ],
            'phone' => 'nullable|string|max:20',
            'profile_image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        // ✅ Update fields
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;

        // ✅ Image Upload
        if ($request->hasFile('profile_image')) {

            // OLD IMAGE DELETE (important)
            if ($user->profile_image && file_exists(public_path('uploads/users/' . $user->profile_image))) {
                unlink(public_path('uploads/users/' . $user->profile_image));
            }

            $file = $request->file('profile_image');
            $filename = time() . '.' . $file->getClientOriginalExtension();

            $file->move(public_path('uploads/users'), $filename);

            $user->profile_image = $filename;
        }

        $user->save();

        return back()->with('success', 'Profile updated successfully');
    }

    public function updateDetails(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'address' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:100',
            'country' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:100',
            'zip_code' => 'nullable|string|max:20',
            'about' => 'nullable|string',
        ]);

        UserProfile::updateOrCreate(
            ['user_id' => $user->id],
            [
                'address' => $request->address,
                'city' => $request->city,
                'country' => $request->country,
                'state' => $request->state,
                'zip_code' => $request->zip_code,
                'about' => $request->about,
            ]
        );

        return back()->with('success', 'Profile details updated');
    }
}