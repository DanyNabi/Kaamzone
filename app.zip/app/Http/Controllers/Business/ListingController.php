<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\BusinessListing;
use App\Models\BusinessCategory;
use Illuminate\Support\Facades\Auth;
use App\Services\SubscriptionService;
use Illuminate\Support\Facades\Http;

class ListingController extends Controller
{

    public function index()
    {
        $listings = BusinessListing::where('user_id', Auth::id())
            ->latest()
            ->paginate(10);

        $categories = BusinessCategory::all();

        return view(
            'business.listings.index',
            compact('listings', 'categories')
        );
    }


    public function create()
    {
        $categories = BusinessCategory::all();

        $featuredLimit = SubscriptionService::getLimit(
            Auth::user(),
            'business',
            'featured-businesses'
        );

        $currentFeatured = BusinessListing::where('user_id', Auth::id())
            ->where('is_featured', 1)
            ->whereIn('status', ['pending', 'approved'])
            ->count();

        $remainingFeatured = $featuredLimit;

        if (
            $featuredLimit !== null &&
            $featuredLimit !== PHP_INT_MAX
        ) {
            $remainingFeatured = max(0, $featuredLimit - $currentFeatured);
        }

        return view(
            'business.listings.create',
            compact(
                'categories',
                'featuredLimit',
                'remainingFeatured'
            )
        );
    }

    public function store(Request $request)
    {
        // Check Business Listing Limit
        $currentBusinesses = BusinessListing::where('user_id', Auth::id())
            ->whereIn('status', ['pending', 'approved'])
            ->count();

        $limit = SubscriptionService::getLimit(
            Auth::user(),
            'business',
            'business-listings'
        );

        if (
            $limit !== null &&
            $limit !== PHP_INT_MAX &&
            $currentBusinesses >= $limit
        ) {
            return back()
                ->withInput()
                ->with(
                    'error',
                    'You have reached your business listing limit. Please upgrade your subscription.'
                );
        }

        // Check Featured Business Limit
        $featuredLimit = SubscriptionService::getLimit(
            Auth::user(),
            'business',
            'featured-businesses'
        );

        $currentFeatured = BusinessListing::where('user_id', Auth::id())
            ->where('is_featured', 1)
            ->whereIn('status', ['pending', 'approved'])
            ->count();

        $isFeatured = false;

        if (
            $request->has('is_featured') &&
            (
                $featuredLimit === PHP_INT_MAX ||
                $currentFeatured < $featuredLimit
            )
        ) {
            $isFeatured = true;
        }

        // Business Duration
        $duration = SubscriptionService::getLimit(
            Auth::user(),
            'business',
            'business-duration'
        );

        // Validation
        $request->validate([
            'title' => 'required|max:255',
            'category_id' => 'required',
            'description' => 'required',
            'logo' => 'nullable|image',
            'cover_image' => 'nullable|image',

            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',

            'video' => 'nullable|mimes:mp4,mov,avi,webm|max:51200',
        ]);



        if ($request->hasFile('video') && !$isFeatured) {

            return back()
                ->withInput()
                ->with(
                    'error',
                    'Business video upload is available only for Featured Businesses.'
                );
        }

        // Upload Logo
        $logoName = null;

        if ($request->hasFile('logo')) {

            $logo = $request->file('logo');

            $logoName = time() . '_logo.' . $logo->getClientOriginalExtension();

            $logo->move(
                public_path('uploads/business-listings'),
                $logoName
            );
        }

        // Upload Cover Image
        $coverImage = null;

        if ($request->hasFile('cover_image')) {

            $cover = $request->file('cover_image');

            $coverImage = time() . '_cover.' . $cover->getClientOriginalExtension();

            $cover->move(
                public_path('uploads/business-listings'),
                $coverImage
            );
        }

        $videoName = null;

        if ($request->hasFile('video')) {

            $video = $request->file('video');

            $videoName = time() . '_video.' .
                $video->getClientOriginalExtension();

            $video->move(
                public_path('uploads/business-listings/videos'),
                $videoName
            );
        }

        BusinessListing::create([

            'user_id' => Auth::id(),

            'category_id' => $request->category_id,

            'title' => $request->title,

            'slug' => Str::slug($request->title) . '-' . time(),

            'description' => $request->description,

            'phone' => $request->phone,

            'email' => $request->email,

            'address' => $request->address,

            'city' => $request->city,

            'latitude' => $request->latitude,
            'longitude' => $request->longitude,

            'opening_days' => $request->opening_days,

            'opening_time' => $request->opening_time,

            'closing_time' => $request->closing_time,

            'logo' => $logoName,

            'cover_image' => $coverImage,

            'video' => $videoName,

            'status' => 'pending',

            'is_featured' => $isFeatured,

            'expires_at' =>  null,


        ]);

        return redirect()
            ->route('business.listings.index')
            ->with(
                'success',
                'Business Listing Added Successfully'
            );
    }

    public function destroy($id)
    {
        $listing = BusinessListing::where('user_id', Auth::id())
            ->findOrFail($id);

        // Delete Logo
        if (
            $listing->logo &&
            file_exists(public_path('uploads/business-listings/' . $listing->logo))
        ) {

            unlink(public_path('uploads/business-listings/' . $listing->logo));
        }

        // Delete Cover Image
        if (
            $listing->cover_image &&
            file_exists(public_path('uploads/business-listings/' . $listing->cover_image))
        ) {

            unlink(public_path('uploads/business-listings/' . $listing->cover_image));
        }

        // Delete Record
        $listing->delete();

        return redirect()
            ->route('business.listings.index')
            ->with('success', 'Business Listing Deleted Successfully');
    }

    public function edit($id)
    {
        $listing = BusinessListing::where('user_id', Auth::id())
            ->findOrFail($id);

        $categories = BusinessCategory::all();

        $featuredLimit = SubscriptionService::getLimit(
            Auth::user(),
            'business',
            'featured-businesses'
        );

        $currentFeatured = BusinessListing::where('user_id', Auth::id())
            ->where('is_featured', 1)
            ->whereIn('status', ['pending', 'approved'])
            ->count();

        // Current listing agar featured hai to usko count se minus kar do
        if ($listing->is_featured) {
            $currentFeatured--;
        }

        $remainingFeatured = $featuredLimit;

        if (
            $featuredLimit !== null &&
            $featuredLimit !== PHP_INT_MAX
        ) {
            $remainingFeatured = max(0, $featuredLimit - $currentFeatured);
        }

        return view(
            'business.listings.edit',
            compact(
                'listing',
                'categories',
                'featuredLimit',
                'remainingFeatured'
            )
        );
    }

    public function update(Request $request, $id)
    {
        $listing = BusinessListing::where('user_id', Auth::id())
            ->findOrFail($id);

        $request->validate([
            'title' => 'required|max:255',
            'category_id' => 'required',
            'description' => 'required',
            'logo' => 'nullable|image',
            'cover_image' => 'nullable|image',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
            'video' => 'nullable|mimes:mp4,mov,avi,webm|max:51200',
        ]);

        /*
    |--------------------------------------------------------------------------
    | Featured Business Limit
    |--------------------------------------------------------------------------
    */

        $featuredLimit = SubscriptionService::getLimit(
            Auth::user(),
            'business',
            'featured-businesses'
        );

        $currentFeatured = BusinessListing::where('user_id', Auth::id())
            ->where('is_featured', 1)
            ->whereIn('status', ['pending', 'approved'])
            ->count();

        if ($listing->is_featured) {
            $currentFeatured--;
        }

        $isFeatured = false;

        if (
            $request->has('is_featured') &&
            (
                $featuredLimit === PHP_INT_MAX ||
                $currentFeatured < $featuredLimit
            )
        ) {
            $isFeatured = true;
        }

        if ($request->hasFile('video') && !$isFeatured) {

            return back()
                ->withInput()
                ->with(
                    'error',
                    'Business video upload is available only for Featured Businesses.'
                );
        }

        /*
    |--------------------------------------------------------------------------
    | Logo
    |--------------------------------------------------------------------------
    */

        if ($request->hasFile('logo')) {

            if (
                $listing->logo &&
                file_exists(public_path('uploads/business-listings/' . $listing->logo))
            ) {
                unlink(public_path('uploads/business-listings/' . $listing->logo));
            }

            $logo = $request->file('logo');

            $logoName = time() . '_logo.' . $logo->getClientOriginalExtension();

            $logo->move(
                public_path('uploads/business-listings'),
                $logoName
            );

            $listing->logo = $logoName;
        }

        /*
    |--------------------------------------------------------------------------
    | Cover
    |--------------------------------------------------------------------------
    */

        if ($request->hasFile('cover_image')) {

            if (
                $listing->cover_image &&
                file_exists(public_path('uploads/business-listings/' . $listing->cover_image))
            ) {
                unlink(public_path('uploads/business-listings/' . $listing->cover_image));
            }

            $cover = $request->file('cover_image');

            $coverImage = time() . '_cover.' . $cover->getClientOriginalExtension();

            $cover->move(
                public_path('uploads/business-listings'),
                $coverImage
            );

            $listing->cover_image = $coverImage;
        }

        /*
    |--------------------------------------------------------------------------
    | Video
    |--------------------------------------------------------------------------
    */

        if ($request->hasFile('video')) {

            if (
                $listing->video &&
                file_exists(public_path('uploads/business-listings/videos/' . $listing->video))
            ) {
                unlink(public_path('uploads/business-listings/videos/' . $listing->video));
            }

            $video = $request->file('video');

            $videoName = time() . '_video.' .
                $video->getClientOriginalExtension();

            $video->move(
                public_path('uploads/business-listings/videos'),
                $videoName
            );

            $listing->video = $videoName;
        }

        /*
    |--------------------------------------------------------------------------
    | Featured Removed
    |--------------------------------------------------------------------------
    */

        if (!$request->has('is_featured')) {

            if (
                $listing->video &&
                file_exists(public_path('uploads/business-listings/videos/' . $listing->video))
            ) {
                unlink(public_path('uploads/business-listings/videos/' . $listing->video));
            }

            $listing->video = null;
        }

        /*
    |--------------------------------------------------------------------------
    | Update
    |--------------------------------------------------------------------------
    */

        $listing->category_id = $request->category_id;
        $listing->title = $request->title;
        $listing->slug = Str::slug($request->title);
        $listing->description = $request->description;
        $listing->phone = $request->phone;
        $listing->email = $request->email;
        $listing->address = $request->address;
        $listing->city = $request->city;
        $listing->latitude = $request->latitude;
        $listing->longitude = $request->longitude;
        $listing->opening_days = $request->opening_days;
        $listing->opening_time = $request->opening_time;
        $listing->closing_time = $request->closing_time;
        $listing->is_featured = $isFeatured;

        $listing->save();

        return redirect()
            ->route('business.listings.index')
            ->with(
                'success',
                'Business Listing Updated Successfully'
            );
    }
}
