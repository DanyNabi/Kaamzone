<?php

namespace App\Http\Controllers\Service;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Bid;
use App\Http\Controllers\Controller;
use App\Models\ServiceRequest;

class JobController extends Controller
{
   public function index()
    {
        $jobs = ServiceRequest::where(
            'assigned_provider_id',
            Auth::id()
        )
        ->whereIn('status', [
            'in_progress',
            'completed'
        ])
        ->with([
            'user',
            'acceptedBid',
            'review'
        ])
        ->latest()
        ->paginate(10);

        return view(
            'service.jobs.index',
            compact('jobs')
        );
    }

    public function show($id)
    {
        $job = Bid::with([
                'serviceRequest',
                'provider'
            ])
            ->where('provider_id', Auth::id())
            ->findOrFail($id);

        return view(
            'service.jobs.show',
            compact('job')
        );
    }
}
