<?php

namespace App\Http\Controllers\Service;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\ProviderProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\ProviderCategory;
use App\Models\ProviderCategoryPivot;

class ProfileController extends Controller
{
    public function edit()
    {
        $profile = Auth::user()->providerProfile;

        $categories = ProviderCategory::where(
            'status',
            1
        )->get();

        return view(
            'service.gigprofile.edit',
            compact(
                'profile',
                'categories'
            )
        );
    }
    public function update(Request $request)
    {
        $request->validate([

            'bio' => 'nullable',
            'skills' => 'nullable',
            'experience' => 'nullable|integer',
            'profile_image' => 'nullable|image',

            'provider_category_id' => 'required',
            'provider_sub_category_id' => 'required',

        ]);

        $profile = ProviderProfile::firstOrCreate([
            'user_id' => Auth::id()
        ]);

        if ($request->hasFile('profile_image')) {

            $image = $request->file('profile_image');

            $imageName = time() . '.' .
                $image->getClientOriginalExtension();

            $image->move(
                public_path('uploads/providers'),
                $imageName
            );

            $profile->profile_image =
                'uploads/providers/' . $imageName;
        }

        $profile->bio = $request->bio;

        $profile->skills = $request->skills;

        $profile->experience = $request->experience;

        $profile->provider_category_id =
            $request->provider_category_id;

        $profile->provider_sub_category_id =
            $request->provider_sub_category_id;

        $profile->save();

        return back()->with(
            'success',
            'Profile updated successfully.'
        );
    }
}
