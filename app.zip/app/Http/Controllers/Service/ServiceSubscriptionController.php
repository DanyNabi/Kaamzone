<?php

namespace App\Http\Controllers\Provider;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionModule;
use App\Models\SubscriptionOrder;
use App\Models\SubscriptionPlan;
use App\Models\UserSubscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class ServiceSubscriptionController extends Controller
{
    private function module()
    {
        return SubscriptionModule::where('slug', 'services')->firstOrFail();
    }

    public function index()
    {
        $module = $this->module();

        $subscription = UserSubscription::with([
            'module',
            'plan.planFeatures.feature'
        ])
            ->where('user_id', Auth::id())
            ->where('module_id', $module->id)
            ->where('status', 'active')
            ->first();

        return view(
            'service.subscription.index',
            compact('subscription')
        );
    }

    public function plans()
    {
        $module = $this->module();

        $plans = SubscriptionPlan::with([
            'planFeatures.feature'
        ])
            ->where('module_id', $module->id)
            ->where('status', 1)
            ->orderBy('sort_order')
            ->get();

        $currentSubscription = UserSubscription::where(
            'user_id',
            Auth::id()
        )
            ->where('module_id', $module->id)
            ->where('status', 'active')
            ->first();

        return view(
            'service.subscription.plans',
            compact(
                'plans',
                'currentSubscription'
            )
        );
    }

    public function upgrade($planId)
    {
        $module = $this->module();

        $plan = SubscriptionPlan::with('planFeatures.feature')
            ->where('module_id', $module->id)
            ->findOrFail($planId);

        return view(
            'service.subscription.upgrade',
            compact('plan')
        );
    }

    public function createOrder(Request $request)
    {
        $module = $this->module();

        $plan = SubscriptionPlan::where('module_id', $module->id)
            ->findOrFail($request->plan_id);

        $existing = SubscriptionOrder::where('user_id', Auth::id())
            ->where('module_id', $module->id)
            ->where('plan_id', $plan->id)
            ->where('status', 'pending')
            ->first();

        if ($existing) {

            return redirect()->route(
                'service.subscription.orders.show',
                $existing->id
            );
        }

        $order = SubscriptionOrder::create([

            'order_no' => 'SUB-' . strtoupper(Str::random(8)),

            'user_id' => Auth::id(),

            'module_id' => $module->id,

            'plan_id' => $plan->id,

            'amount' => $plan->price,

            'status' => 'pending',

        ]);

        return redirect()->route(
            'service.subscription.orders.show',
            $order->id
        );
    }

    public function orders()
    {
        $module = $this->module();

        $orders = SubscriptionOrder::with('plan')
            ->where('user_id', Auth::id())
            ->where('module_id', $module->id)
            ->latest()
            ->paginate(10);

        return view(
            'service.subscription.orders',
            compact('orders')
        );
    }

    public function show($id)
    {
        $module = $this->module();

        $order = SubscriptionOrder::with('plan')
            ->where('user_id', Auth::id())
            ->where('module_id', $module->id)
            ->findOrFail($id);

        return view(
            'service.subscription.show',
            compact('order')
        );
    }

    public function uploadProof(Request $request, $id)
    {
        $request->validate([
            'payment_proof' => 'required|image|mimes:jpg,jpeg,png|max:2048'
        ]);

        $module = $this->module();

        $order = SubscriptionOrder::where('user_id', Auth::id())
            ->where('module_id', $module->id)
            ->findOrFail($id);

        if ($request->hasFile('payment_proof')) {

            $image = $request->file('payment_proof');

            $name = time() . '.' . $image->getClientOriginalExtension();

            $image->move(
                public_path('uploads/payment-proofs'),
                $name
            );

            $order->payment_proof = $name;

            $order->save();
        }

        return back()->with(
            'success',
            'Payment proof uploaded successfully.'
        );
    }

    public function history()
    {
        $module = $this->module();

        $orders = SubscriptionOrder::with('plan')
            ->where('user_id', Auth::id())
            ->where('module_id', $module->id)
            ->where('status', 'approved')
            ->latest()
            ->paginate(10);

        return view(
            'service.subscription.history',
            compact('orders')
        );
    }
}