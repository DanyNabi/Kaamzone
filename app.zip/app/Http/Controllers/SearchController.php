<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\ServiceRequest;
use App\Models\BusinessListing;
use App\Models\CareerJob;

class SearchController extends Controller
{
    public function index(Request $request)
    {
        $keyword = $request->keyword;
        $type = $request->type;
        $location = $request->location;

        $products = collect();
        $services = collect();
        $businesses = collect();
        $jobs = collect();

        /*
    |--------------------------------------------------------------------------
    | Products
    |--------------------------------------------------------------------------
    */

        if ($type == 'listing' || empty($type)) {

            $products = Product::with('images')
                ->where('status', 'approved')
                ->when($keyword, function ($q) use ($keyword) {
                    $q->where(function ($query) use ($keyword) {
                        $query->where('title', 'like', "%{$keyword}%")
                            ->orWhere('description', 'like', "%{$keyword}%");
                    });
                })
                ->latest()
                ->paginate(9, ['*'], 'products_page');
        }

        /*
    |--------------------------------------------------------------------------
    | Services
    |--------------------------------------------------------------------------
    */

        if ($type == 'service' || empty($type)) {

            $services = ServiceRequest::query()

                ->where('status', 'approved')

                ->when($keyword, function ($q) use ($keyword) {

                    $q->where(function ($query) use ($keyword) {

                        $query->where('title', 'like', "%{$keyword}%")
                            ->orWhere('description', 'like', "%{$keyword}%");
                    });
                })

                ->when($location, function ($q) use ($location) {

                    $q->where('location', 'like', "%{$location}%");
                })

                ->latest()
                ->paginate(9, ['*'], 'services_page');
        }

        /*
    |--------------------------------------------------------------------------
    | Businesses
    |--------------------------------------------------------------------------
    */

        if ($type == 'business' || empty($type)) {

            $businesses = BusinessListing::query()

                ->where('status', 'approved')

                ->when($keyword, function ($q) use ($keyword) {

                    $q->where(function ($query) use ($keyword) {

                        $query->where('title', 'like', "%{$keyword}%")
                            ->orWhere('description', 'like', "%{$keyword}%");
                    });
                })

                ->when($location, function ($q) use ($location) {

                    $q->where(function ($query) use ($location) {

                        $query->where('city', 'like', "%{$location}%")
                            ->orWhere('address', 'like', "%{$location}%");
                    });
                })

                ->latest()
                ->paginate(9, ['*'], 'businesses_page');
        }

        /*
    |--------------------------------------------------------------------------
    | Jobs
    |--------------------------------------------------------------------------
    */

        if ($type == 'job' || empty($type)) {

            $jobs = CareerJob::query()

                ->where('status', 'approved')

                ->when($keyword, function ($q) use ($keyword) {

                    $q->where(function ($query) use ($keyword) {

                        $query->where('title', 'like', "%{$keyword}%")
                            ->orWhere('company_name', 'like', "%{$keyword}%")
                            ->orWhere('description', 'like', "%{$keyword}%");
                    });
                })

                ->when($location, function ($q) use ($location) {

                    $q->where('location', 'like', "%{$location}%");
                })

                ->latest()
                ->paginate(9, ['*'], 'jobs_page');
        }

        return view('search.index', compact(
            'keyword',
            'type',
            'location',
            'products',
            'services',
            'businesses',
            'jobs'
        ));
    }
}
