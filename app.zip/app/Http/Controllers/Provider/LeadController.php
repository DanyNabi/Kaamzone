<?php

namespace App\Http\Controllers\Provider;

use App\Http\Controllers\Controller;
use App\Models\ServiceRequest;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\ProviderCategoryPivot;
use Illuminate\Support\Facades\Auth;
use App\Services\SubscriptionService;

class LeadController extends Controller
{
    public function index(Request $request)
    {
        // PROVIDER CATEGORY IDS

        $providerCategoryIds = ProviderCategoryPivot::where(
            'provider_id',
            Auth::id()
        )
            ->pluck('provider_category_id');

        // BASE QUERY

        $query = ServiceRequest::whereIn(
            'provider_category_id',
            $providerCategoryIds
        )

            // ONLY OPEN LEADS

            ->whereNotIn('status', [
                'closed',
                'done',
                'in_progress',
                'completed'
            ]);

        // TIME FILTERS

        if ($request->filter == '24hours') {

            $query->where(
                'created_at',
                '>=',
                Carbon::now()->subHours(24)
            );
        } elseif ($request->filter == 'week') {

            $query->where(
                'created_at',
                '>=',
                Carbon::now()->subWeek()
            );
        } elseif ($request->filter == 'month') {

            $query->where(
                'created_at',
                '>=',
                Carbon::now()->subMonth()
            );
        }

        // GET LEADS

        $leads = $query
            ->latest()
            ->paginate(10);

        return view(
            'service.leads.index',
            compact('leads')
        );
    }
    public function show($id)
    {
        $lead = ServiceRequest::with([
            'user',
            'images',
            'bids'
        ])->findOrFail($id);

        // Similar leads

        $similarLeads = ServiceRequest::where('id', '!=', $lead->id)
            ->where('status', 'open')
            ->latest()
            ->take(5)
            ->get();

        return view(
            'service.leads.show',
            compact(
                'lead',
                'similarLeads'
            )
        );
    }
}
