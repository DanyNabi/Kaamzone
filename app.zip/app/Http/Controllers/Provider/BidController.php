<?php

namespace App\Http\Controllers\Provider;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Bid;
use Illuminate\Support\Facades\Auth;
use App\Services\SubscriptionService;

class BidController extends Controller
{
   public function store(Request $request)
{
    // Daily Quotes Limit

    $dailyLimit = SubscriptionService::getLimit(
        Auth::user(),
        'services',
        'quotes-per-day'
    );

    $currentQuotes = Bid::where('provider_id', Auth::id())
        ->whereDate('created_at', today())
        ->count();

    if (
        $dailyLimit !== null &&
        $dailyLimit !== PHP_INT_MAX &&
        $currentQuotes >= $dailyLimit
    ) {

        return back()
            ->withInput()
            ->with(
                'error',
                "You have reached your daily quotes limit ({$dailyLimit}). Please upgrade your subscription."
            );
    }

    // Validation

    $request->validate([
        'service_request_id' => 'required',
        'amount' => 'required|numeric',
        'message' => 'required',
        'delivery_days' => 'nullable|integer'
    ]);

    // Already Submitted?

    $exists = Bid::where('provider_id', Auth::id())
        ->where('service_request_id', $request->service_request_id)
        ->exists();

    if ($exists) {

        return back()->with(
            'error',
            'You have already submitted a quote for this request.'
        );
    }

    // Save Bid

    Bid::create([

        'service_request_id' => $request->service_request_id,

        'provider_id' => Auth::id(),

        'amount' => $request->amount,

        'message' => $request->message,

        'delivery_days' => $request->delivery_days,

    ]);

    return back()->with(
        'success',
        'Quote submitted successfully.'
    );
}
}
