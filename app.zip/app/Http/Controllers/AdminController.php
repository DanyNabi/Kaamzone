<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use App\Models\UserProfile;
use App\Models\Product;
use App\Models\BusinessListing;
use App\Models\ServiceRequest;
use App\Models\CareerJob;
use App\Mail\UserApprovedMail;
use Illuminate\Support\Facades\Mail;

class AdminController extends Controller
{
    public function index()
    {
        $totalVendors = User::where('role', 'vendor')->count();

        $totalBusinessesUsers = User::where('role', 'business')->count();

        $totalServiceProviders = User::where('role', 'service_provider')->count();

        $totalEmployers = User::where('role', 'employer')->count();

        $totalJobSeekers = User::where('role', 'job_seeker')->count();

        $totalCustomers = User::where('role', 'customer')->count();
        /*
    |--------------------------------------------------------------------------
    | USERS
    |--------------------------------------------------------------------------
    */

        $totalUsers = User::where('role', '!=', 'admin')->count();

        $pendingUsers = User::where('role', '!=', 'admin')
            ->where('status', 'pending')
            ->count();

        $approvedUsers = User::where('role', '!=', 'admin')
            ->where('status', 'approved')
            ->count();

        $rejectedUsers = User::where('role', '!=', 'admin')
            ->where('status', 'rejected')
            ->count();


        /*
    |--------------------------------------------------------------------------
    | PRODUCTS
    |--------------------------------------------------------------------------
    */

        $totalProducts = Product::count();

        $pendingProducts = Product::where('status', 'pending')->count();

        $approvedProducts = Product::where('status', 'approved')->count();

        $rejectedProducts = Product::where('status', 'rejected')->count();


        /*
    |--------------------------------------------------------------------------
    | BUSINESSES
    |--------------------------------------------------------------------------
    */

        $totalBusinesses = BusinessListing::count();

        $pendingBusinesses = BusinessListing::where('status', 'pending')->count();

        $approvedBusinesses = BusinessListing::where('status', 'approved')->count();

        $rejectedBusinesses = BusinessListing::where('status', 'rejected')->count();


        /*
    |--------------------------------------------------------------------------
    | SERVICES
    |--------------------------------------------------------------------------
    */

        $totalServices = ServiceRequest::count();

        $pendingServices = ServiceRequest::where('status', 'pending')->count();

        $approvedServices = ServiceRequest::where('status', 'approved')->count();

        $rejectedServices = ServiceRequest::where('status', 'rejected')->count();


        /*
|--------------------------------------------------------------------------
| JOBS
|--------------------------------------------------------------------------
*/

        $totalJobs = CareerJob::count();

        $pendingJobs = CareerJob::where('status', 'pending')->count();

        $approvedJobs = CareerJob::where('status', 'approved')->count();

        $rejectedJobs = CareerJob::where('status', 'rejected')->count();

        $totalJobApplications = \App\Models\JobApplication::count();


        /*
    |--------------------------------------------------------------------------
    | RECENT RECORDS
    |--------------------------------------------------------------------------
    */

        $recentProducts = Product::with('user')
            ->latest()
            ->take(5)
            ->get();

        $recentBusinesses = BusinessListing::with([
            'user',
            'category'
        ])
            ->latest()
            ->take(5)
            ->get();

        $recentServices = ServiceRequest::with([
            'user',
            'category',
            'subCategory'
        ])
            ->latest()
            ->take(5)
            ->get();

        $recentUsers = User::where('role', '!=', 'admin')
            ->latest()
            ->take(5)
            ->get();

        $recentJobs = CareerJob::with([
            'employer',
            'category'
        ])
            ->latest()
            ->take(5)
            ->get();


        /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

        return view('admin.dashboard', compact(

            'totalVendors',
            'totalBusinessesUsers',
            'totalServiceProviders',
            'totalEmployers',
            'totalJobSeekers',
            'totalCustomers',

            // Users
            'totalUsers',
            'pendingUsers',
            'approvedUsers',
            'rejectedUsers',

            // Products
            'totalProducts',
            'pendingProducts',
            'approvedProducts',
            'rejectedProducts',

            // Businesses
            'totalBusinesses',
            'pendingBusinesses',
            'approvedBusinesses',
            'rejectedBusinesses',

            // Services
            'totalServices',
            'pendingServices',
            'approvedServices',
            'rejectedServices',

            // Jobs
            'totalJobs',
            'pendingJobs',
            'approvedJobs',
            'rejectedJobs',
            'totalJobApplications',



            // Recent
            'recentProducts',
            'recentBusinesses',
            'recentServices',
            'recentJobs',
            'recentUsers'
        ));
    }

    public function users(Request $request)
    {
        $query = \App\Models\User::where('role', '!=', 'admin');

        // 🎯 Filter apply
        if ($request->status && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        $users = $query->latest()->paginate(10);

        return view('admin.userList', compact('users'));
    }

    public function approve($id)
    {
        $user = User::findOrFail($id);
        $user->status = 'approved';
        $user->save();

         Mail::to($user->email)->send(new UserApprovedMail($user));

    return redirect()->back()
        ->with('success', 'User approved and email sent successfully.');
    }

    public function reject($id)
    {
        $user = User::findOrFail($id);
        $user->status = 'rejected';
        $user->save();

        return back()->with('success', 'User rejected');
    }


    public function updateProfile(Request $request)
    {
        $user = Auth::user();

        // ✅ Validation (email unique fix)
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'email',
                Rule::unique('users')->ignore($user->id),
            ],
            'phone' => 'nullable|string|max:20',
            'profile_image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        // ✅ Update fields
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;

        // ✅ Image Upload
        if ($request->hasFile('profile_image')) {

            // OLD IMAGE DELETE (important)
            if ($user->profile_image && file_exists(public_path('uploads/users/' . $user->profile_image))) {
                unlink(public_path('uploads/users/' . $user->profile_image));
            }

            $file = $request->file('profile_image');
            $filename = time() . '.' . $file->getClientOriginalExtension();

            $file->move(public_path('uploads/users'), $filename);

            $user->profile_image = $filename;
        }

        $user->save();

        return back()->with('success', 'Profile updated successfully');
    }

    public function updateDetails(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'address' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:100',
            'country' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:100',
            'zip_code' => 'nullable|string|max:20',
            'about' => 'nullable|string',
        ]);

        UserProfile::updateOrCreate(
            ['user_id' => $user->id],
            [
                'address' => $request->address,
                'city' => $request->city,
                'country' => $request->country,
                'state' => $request->state,
                'zip_code' => $request->zip_code,
                'about' => $request->about,
            ]
        );

        return back()->with('success', 'Profile details updated');
    }
}
