<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http;

class NewsController extends Controller
{
    public function ticker()
    {
        $news = [];

        try {
            $rss = simplexml_load_file('https://feeds.feedburner.com/dawn-news');

            foreach ($rss->channel->item as $item) {
                $news[] = [
                    'title' => (string) $item->title,
                    'link'  => (string) $item->link,
                ];

                if (count($news) >= 10) {
                    break;
                }
            }
        } catch (\Exception $e) {
            $news = [];
        }

        return view('news-ticker', compact('news'));
    }   
}
