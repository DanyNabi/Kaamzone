<?php

namespace App\Repositories;

use App\Models\ResumePersonalInfo;
use App\Repositories\Interfaces\ResumePersonalInfoRepositoryInterface;

class ResumePersonalInfoRepository implements ResumePersonalInfoRepositoryInterface
{
    public function updateOrCreate(int $resumeId, array $data)
    {
        return ResumePersonalInfo::updateOrCreate(
            [
                'resume_id' => $resumeId,
            ],
            $data
        );
    }
}
