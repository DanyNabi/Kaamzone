<?php

namespace App\Repositories;

use App\Models\ResumeSkill;

class ResumeSkillRepository
{
    public function create(array $data)
    {
        return ResumeSkill::create($data);
    }

    public function update(ResumeSkill $skill, array $data)
    {
        $skill->update($data);

        return $skill->fresh();
    }

    public function delete(ResumeSkill $skill)
    {
        return $skill->delete();
    }
}
