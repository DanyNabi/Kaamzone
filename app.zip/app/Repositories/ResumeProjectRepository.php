<?php

namespace App\Repositories;

use App\Models\ResumeProject;

class ResumeProjectRepository
{
    public function create(array $data)
    {
        return ResumeProject::create($data);
    }

    public function update(ResumeProject $project, array $data)
    {
        $project->update($data);

        return $project->fresh();
    }

    public function delete(ResumeProject $project)
    {
        return $project->delete();
    }
}