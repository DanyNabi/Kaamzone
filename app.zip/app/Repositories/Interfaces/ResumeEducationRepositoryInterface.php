<?php

namespace App\Repositories\Interfaces;

interface ResumeEducationRepositoryInterface
{
    public function create(array $data);

    public function update($id, array $data);

    public function delete($id);
}