<?php

namespace App\Repositories\Interfaces;

use App\Models\Resume;

interface ResumeRepositoryInterface
{
    public function all($userId);

    public function find($id);

    public function create(array $data): Resume;

    public function update(Resume $resume, array $data): bool;

    public function delete(Resume $resume): bool;

    public function findWithRelations($id);
}
