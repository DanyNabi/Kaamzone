<?php
namespace App\Repositories\Interfaces;

interface ResumePersonalInfoRepositoryInterface
{
    public function updateOrCreate(int $resumeId, array $data);
}