<?php

namespace App\Repositories\Interfaces;

interface ResumeExperienceRepositoryInterface
{
    public function create(int $resumeId, array $data);

    public function update(int $id, array $data);

    public function delete(int $id);

    public function findByResume(int $resumeId);

    public function findById(int $id);
}