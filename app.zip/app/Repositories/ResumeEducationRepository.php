<?php

namespace App\Repositories;

use App\Models\ResumeEducation;
use App\Repositories\Interfaces\ResumeEducationRepositoryInterface;

class ResumeEducationRepository implements ResumeEducationRepositoryInterface
{
    public function create(array $data)
    {
        return ResumeEducation::create($data);
    }

    public function update($id, array $data)
    {
        $education = ResumeEducation::findOrFail($id);

        $education->update($data);

        return $education->fresh();
    }

    public function delete($id)
    {
        return ResumeEducation::findOrFail($id)->delete();
    }
}