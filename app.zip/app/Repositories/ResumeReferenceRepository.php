<?php

namespace App\Repositories;

use App\Models\ResumeReference;

class ResumeReferenceRepository
{
    public function create(array $data)
    {
        return ResumeReference::create($data);
    }

    public function update(ResumeReference $reference, array $data)
    {
        $reference->update($data);

        return $reference->fresh();
    }

    public function delete(ResumeReference $reference)
    {
        return $reference->delete();
    }
}