<?php

namespace App\Repositories;

use App\Models\ResumeLanguage;

class ResumeLanguageRepository
{
    public function create(array $data)
    {
        return ResumeLanguage::create($data);
    }

    public function update(ResumeLanguage $language, array $data)
    {
        $language->update($data);

        return $language->fresh();
    }

    public function delete(ResumeLanguage $language)
    {
        return $language->delete();
    }
}