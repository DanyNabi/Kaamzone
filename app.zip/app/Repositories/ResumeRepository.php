<?php

namespace App\Repositories;

use App\Models\Resume;
use App\Repositories\Interfaces\ResumeRepositoryInterface;

class ResumeRepository implements ResumeRepositoryInterface
{
    public function all($userId)
    {
        return Resume::where('user_id', $userId)
            ->latest()
            ->get();
    }

    public function find($id)
    {
        return Resume::findOrFail($id);
    }

    public function create(array $data): Resume
    {
        return Resume::create($data);
    }

    public function update(Resume $resume, array $data): bool
    {
        return $resume->update($data);
    }

    public function delete(Resume $resume): bool
    {
        return $resume->delete();
    }

    public function findWithRelations($id)
    {
        return Resume::with([
            'personalInfo',
            'experiences',
            'educations',
            'skills',
            'projects',
            'certifications',
            'languages',
            'references',
            'sections',
        ])->findOrFail($id);
    }
}
