<?php

namespace App\Repositories;

use App\Models\ResumeCertification;

class ResumeCertificationRepository
{
    public function create(array $data)
    {
        return ResumeCertification::create($data);
    }

    public function update(ResumeCertification $certification, array $data)
    {
        $certification->update($data);

        return $certification->fresh();
    }

    public function delete(ResumeCertification $certification)
    {
        return $certification->delete();
    }
}