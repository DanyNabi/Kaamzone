<?php

namespace App\Repositories;

use App\Models\ResumeExperience;
use App\Repositories\Interfaces\ResumeExperienceRepositoryInterface;

class ResumeExperienceRepository implements ResumeExperienceRepositoryInterface
{
    public function create(int $resumeId, array $data)
    {
        $data['resume_id'] = $resumeId;

        return ResumeExperience::create($data);
    }

    public function update(int $id, array $data)
    {
        $experience = ResumeExperience::findOrFail($id);

        $experience->update($data);

        return $experience;
    }

    public function delete(int $id)
    {
        return ResumeExperience::findOrFail($id)->delete();
    }

    public function findByResume(int $resumeId)
    {
        return ResumeExperience::where('resume_id', $resumeId)
            ->orderBy('sort_order')
            ->get();
    }

    public function findById(int $id)
    {
        return ResumeExperience::findOrFail($id);
    }
}