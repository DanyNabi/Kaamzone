<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Product;

class ExpireProducts extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'products:expire';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Expire old marketplace products';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $count = Product::whereNotNull('expires_at')
            ->where('expires_at', '<=', now())
            ->whereIn('status', ['pending', 'approved'])
            ->update([
                'status' => 'expired',
            ]);

        $this->info("{$count} product(s) expired successfully.");

        return self::SUCCESS;
    }
}