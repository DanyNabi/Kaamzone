<?php

namespace App\Console\Commands;

use App\Models\User;
use App\Notifications\IncompleteProfileReminderNotification;
use Illuminate\Console\Command;

class SendIncompleteProfileReminders extends Command
{
    protected $signature = 'profiles:send-reminders';

    protected $description = 'Send reminders to users with incomplete profiles';

    public function handle()
    {
        $users = User::query()
            ->where('role', '!=', 'admin')
            ->where(function ($query) {
                $query->whereNull('profile_reminder_sent_at')
                    ->orWhere(
                        'profile_reminder_sent_at',
                        '<=',
                        now()->subDays(3)
                    );
            })
            ->get();

        $sent = 0;

        foreach ($users as $user) {

            // Profile complete hai to email nahi jayegi
            if ($user->isProfileComplete()) {
                continue;
            }

            // Incomplete profile → email
            $user->notify(
                new IncompleteProfileReminderNotification()
            );

            // Last reminder time save karo
            $user->update([
                'profile_reminder_sent_at' => now(),
            ]);

            $sent++;
        }

        $this->info("Profile reminder emails sent: {$sent}");

        return self::SUCCESS;
    }
}