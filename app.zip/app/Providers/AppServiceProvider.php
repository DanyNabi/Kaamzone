<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\View;
use App\Models\WebsiteSetting;
use App\Repositories\Interfaces\ResumeRepositoryInterface;
use App\Repositories\ResumeRepository;
use App\Repositories\ResumePersonalInfoRepository;
use App\Repositories\Interfaces\ResumePersonalInfoRepositoryInterface;
use App\Repositories\ResumeExperienceRepository;
use App\Repositories\Interfaces\ResumeExperienceRepositoryInterface;
use App\Repositories\Interfaces\ResumeEducationRepositoryInterface;
use App\Repositories\ResumeEducationRepository;
use App\Models\Category;
use App\Models\BusinessCategory;
use App\Models\ProviderCategory;
use App\Models\JobCategory;


class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->bind(
            ResumeRepositoryInterface::class,
            ResumeRepository::class
        );

        $this->app->bind(
            ResumePersonalInfoRepositoryInterface::class,
            ResumePersonalInfoRepository::class
        );

        $this->app->bind(
            ResumeExperienceRepositoryInterface::class,
            ResumeExperienceRepository::class
        );

        $this->app->bind(
            ResumeEducationRepositoryInterface::class,
            ResumeEducationRepository::class
        );
    }

    /**
     * Bootstrap any application services.
     */
    public function boot()
    {
        App::setLocale(session('locale', 'en'));
        Paginator::useBootstrap();

        View::composer('*', function ($view) {

            $settings = WebsiteSetting::first();

            $view->with('settings', $settings);
        });

        View::composer('*', function ($view) {

            $view->with([

                // Buy & Sell
                'navCategories' => Category::orderBy('name')->get(),

                // Business
                'navBusinessCategories' => BusinessCategory::orderBy('name')->get(),

                // Services
                'navProviderCategories' => ProviderCategory::orderBy('name')->get(),

                // Jobs
                'navJobCategories' => JobCategory::orderBy('name')->get(),

            ]);
        });
    }
}
