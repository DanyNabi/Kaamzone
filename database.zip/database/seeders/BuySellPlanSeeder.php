<?php

namespace Database\Seeders;

use App\Models\SubscriptionModule;
use App\Models\SubscriptionPlan;
use Illuminate\Database\Seeder;

class BuySellPlanSeeder extends Seeder
{
    public function run(): void
    {
        $module = SubscriptionModule::where('slug', 'buy-sell')->first();

        if (!$module) {
            return;
        }

        $plans = [
            [
                'name' => 'Free',
                'price' => 0,
                'sort_order' => 1,
            ],
            [
                'name' => 'Silver',
                'price' => 499,
                'sort_order' => 2,
            ],
            [
                'name' => 'Gold',
                'price' => 999,
                'sort_order' => 3,
                'is_popular' => true,
            ],
            [
                'name' => 'Platinum',
                'price' => 2499,
                'sort_order' => 4,
                'is_featured' => true,
            ],
        ];

        foreach ($plans as $plan) {

            SubscriptionPlan::updateOrCreate(
                [
                    'module_id' => $module->id,
                    'slug'      => strtolower($plan['name']),
                ],
                [
                    'name'           => $plan['name'],
                    'price'          => $plan['price'],
                    'billing_cycle'  => 'monthly',
                    'duration'       => 30,
                    'trial_days'     => 0,
                    'description'    => null,
                    'badge'          => $plan['name'],
                    'color'          => 'primary',
                    'is_popular'     => $plan['is_popular'] ?? false,
                    'is_featured'    => $plan['is_featured'] ?? false,
                    'status'         => true,
                    'sort_order'     => $plan['sort_order'],
                ]
            );
        }
    }
}