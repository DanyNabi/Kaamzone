<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\SubscriptionModule;

class SubscriptionModuleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        SubscriptionModule::insert([
            [
                'name' => 'Buy & Sell',
                'slug' => 'buy-sell',
                'status' => true,
            ],
            [
                'name' => 'Business',
                'slug' => 'business',
                'status' => true,
            ],
            [
                'name' => 'Services',
                'slug' => 'services',
                'status' => true,
            ],
            [
                'name' => 'Jobs',
                'slug' => 'jobs',
                'status' => true,
            ],
        ]);
    }
}
