<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SubscriptionFeature;
use App\Models\SubscriptionModule;

class BuySellFeatureSeeder extends Seeder
{
    public function run(): void
    {
        $module = SubscriptionModule::where('slug', 'buy-sell')->first();

        if (!$module) {
            return;
        }

        $features = [

            [
                'name' => 'Active Ads',
                'slug' => 'active-ads',
                'type' => 'number',
            ],

            [
                'name' => 'Images Per Ad',
                'slug' => 'images-per-ad',
                'type' => 'number',
            ],

            [
                'name' => 'Ad Duration',
                'slug' => 'ad-duration',
                'type' => 'number',
            ],

            [
                'name' => 'Featured Ads',
                'slug' => 'featured-ads',
                'type' => 'number',
            ],

            [
                'name' => 'Top Search Boost',
                'slug' => 'top-search-boost',
                'type' => 'number',
            ],

            [
                'name' => 'Auto Renew Ads',
                'slug' => 'auto-renew-ads',
                'type' => 'boolean',
            ],

            [
                'name' => 'Urgent Badge',
                'slug' => 'urgent-badge',
                'type' => 'boolean',
            ],

            [
                'name' => 'Verified Seller',
                'slug' => 'verified-seller',
                'type' => 'boolean',
            ],

            [
                'name' => 'Priority Search',
                'slug' => 'priority-search',
                'type' => 'boolean',
            ],

            [
                'name' => 'Analytics',
                'slug' => 'analytics',
                'type' => 'boolean',
            ],

            [
                'name' => 'Priority Support',
                'slug' => 'priority-support',
                'type' => 'boolean',
            ],

        ];

        foreach ($features as $feature) {

            SubscriptionFeature::updateOrCreate(

                [
                    'slug' => $feature['slug'],
                    'module_id' => $module->id,
                ],

                [
                    'name' => $feature['name'],
                    'type' => $feature['type'],
                    'status' => true,
                ]

            );
        }
    }
}