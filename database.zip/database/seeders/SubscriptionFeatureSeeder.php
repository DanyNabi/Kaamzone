<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SubscriptionModule;
use App\Models\SubscriptionFeature;

class SubscriptionFeatureSeeder extends Seeder
{
    public function run(): void
    {
        $modules = [

            'buy-sell' => [

                ['Active Ads', 'active-ads', 'number'],
                ['Images Per Ad', 'images-per-ad', 'number'],
                ['Ad Duration', 'ad-duration', 'number'],
                ['Featured Ads', 'featured-ads', 'number'],
                ['Top Search Boost', 'top-search-boost', 'number'],

                ['Auto Renew Ads', 'auto-renew-ads', 'boolean'],
                ['Urgent Badge', 'urgent-badge', 'boolean'],
                ['Verified Seller', 'verified-seller', 'boolean'],
                ['Priority Search', 'priority-search', 'boolean'],
                ['Analytics', 'analytics', 'boolean'],
                ['Priority Support', 'priority-support', 'boolean'],

            ],

            'business' => [

                ['Business Listings', 'business-listings', 'number'],
                ['Gallery Images', 'gallery-images', 'number'],
                ['Featured Businesses', 'featured-businesses', 'number'],
                ['Business Duration', 'business-duration', 'number'],

                ['Verified Business', 'verified-business', 'boolean'],
                ['Priority Listing', 'priority-listing', 'boolean'],
                ['WhatsApp Button', 'whatsapp-button', 'boolean'],
                ['Website Link', 'website-link', 'boolean'],
                ['Google Map', 'google-map', 'boolean'],

            ],

            'services' => [

                ['Active Services', 'active-services', 'number'],
                ['Service Images', 'service-images', 'number'],
                ['Featured Services', 'featured-services', 'number'],

                ['Verified Provider', 'verified-provider', 'boolean'],
                ['Priority Listing', 'priority-listing', 'boolean'],
                ['WhatsApp Button', 'whatsapp-button', 'boolean'],

            ],

            'jobs' => [

                ['Active Jobs', 'active-jobs', 'number'],
                ['Featured Jobs', 'featured-jobs', 'number'],
                ['Job Duration', 'job-duration', 'number'],

                ['Priority Listing', 'priority-listing', 'boolean'],
                ['Highlighted Job', 'highlighted-job', 'boolean'],

            ]

        ];

        foreach ($modules as $slug => $features) {

            $module = SubscriptionModule::where('slug', $slug)->first();

            if (!$module) {
                continue;
            }

            foreach ($features as $feature) {

                SubscriptionFeature::updateOrCreate(

                    [
                        'module_id' => $module->id,
                        'slug'      => $feature[1],
                    ],

                    [
                        'name'   => $feature[0],
                        'type'   => $feature[2],
                        'status' => 1,
                    ]

                );

            }

        }
    }
}