<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('provider_sub_categories', function (Blueprint $table) {
            $table->id();

            $table->foreignId('provider_category_id')
                ->constrained('provider_categories')
                ->cascadeOnDelete();

            $table->string('name');
            $table->string('slug');
            $table->boolean('status')->default(1);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('provider_sub_categories');
    }
};
