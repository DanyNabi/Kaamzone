<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('reviews', function (Blueprint $table) {
            $table->id();

            // Customer

            $table->foreignId('user_id')
                ->constrained()
                ->onDelete('cascade');

            // Provider

            $table->foreignId('provider_id')
                ->constrained('users')
                ->onDelete('cascade');

            // Related Job / Bid

            $table->foreignId('bid_id')
                ->constrained()
                ->onDelete('cascade');

            $table->integer('rating');

            $table->text('comment')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('reviews');
    }
};
