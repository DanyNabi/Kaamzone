<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('job_applications', function (Blueprint $table) {

            $table->id();

            // JOB

            $table->foreignId('career_job_id')
                ->constrained('career_jobs')
                ->onDelete('cascade');

            // USER

            $table->foreignId('user_id')
                ->constrained()
                ->onDelete('cascade');

            // APPLICATION

            $table->string('resume')
                ->nullable();

            $table->longText('cover_letter')
                ->nullable();

            $table->string('status')
                ->default('pending');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('job_applications');
    }
};
