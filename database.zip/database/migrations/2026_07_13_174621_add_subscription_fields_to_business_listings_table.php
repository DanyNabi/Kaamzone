<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('business_listings', function (Blueprint $table) {
             $table->boolean('is_featured')
                ->default(false)
                ->after('status');

            $table->timestamp('expires_at')
                ->nullable()
                ->after('is_featured');

            $table->boolean('is_verified')
                ->default(false)
                ->after('expires_at');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('business_listings', function (Blueprint $table) {
            $table->dropColumn([
                'is_featured',
                'expires_at',
                'is_verified'
            ]);
        });
    }
};
