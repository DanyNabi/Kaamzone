<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('resume_certificates', function (Blueprint $table) {
            $table->id();

            $table->foreignId('resume_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('certificate_name');

            $table->string('issuing_organization');

            $table->date('issue_date')->nullable();

            $table->date('expiry_date')->nullable();

            $table->boolean('does_not_expire')->default(false);

            $table->string('credential_id')->nullable();

            $table->string('credential_url')->nullable();

            $table->longText('description')->nullable();

            $table->integer('sort_order')->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('resume_certificates');
    }
};
