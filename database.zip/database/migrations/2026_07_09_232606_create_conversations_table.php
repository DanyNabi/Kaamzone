<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('conversations', function (Blueprint $table) {
            $table->id();

            // Registered User
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();

            // Guest UUID
            $table->uuid('guest_id')->nullable();

            // Guest Info
            $table->string('name')->nullable();
            $table->string('phone')->nullable();
            $table->string('email')->nullable();

            // guest | user
            $table->enum('type', ['guest', 'user']);

            // open | closed
            $table->enum('status', ['open', 'closed'])->default('open');

            $table->timestamp('last_message_at')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('conversations');
    }
};
