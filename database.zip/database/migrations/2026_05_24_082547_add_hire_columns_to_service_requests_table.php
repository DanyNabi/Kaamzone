<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('service_requests', function (Blueprint $table) {
            // HIRED PROVIDER

            $table->foreignId('assigned_provider_id')
                ->nullable()
                ->after('user_id')
                ->constrained('users')
                ->onDelete('cascade');

            // ACCEPTED BID

            $table->foreignId('accepted_bid_id')
                ->nullable()
                ->after('assigned_provider_id')
                ->constrained('bids')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('service_requests', function (Blueprint $table) {
            $table->dropForeign([
                'assigned_provider_id'
            ]);

            $table->dropForeign([
                'accepted_bid_id'
            ]);

            $table->dropColumn([
                'assigned_provider_id',
                'accepted_bid_id'
            ]);
        });
    }
};
