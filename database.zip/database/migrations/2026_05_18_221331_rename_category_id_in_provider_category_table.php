<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('provider_category', function (Blueprint $table) {
            $table->renameColumn(
                'category_id',
                'provider_category_id'
            );
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('provider_category', function (Blueprint $table) {
            $table->renameColumn(
                'provider_category_id',
                'category_id'
            );
        });
    }
};
