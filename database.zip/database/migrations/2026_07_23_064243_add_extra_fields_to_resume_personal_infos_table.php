<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('resume_personal_infos', function (Blueprint $table) {
            Schema::table('resume_personal_infos', function (Blueprint $table) {

                $table->date('date_of_birth')->nullable()->after('phone');

                $table->enum('gender', ['male', 'female', 'other'])
                    ->nullable()
                    ->after('date_of_birth');

                $table->string('nationality')
                    ->nullable()
                    ->after('gender');

                $table->string('driving_license')
                    ->nullable()
                    ->after('postal_code');
            });
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {

        Schema::table('resume_personal_infos', function (Blueprint $table) {

            $table->dropColumn([
                'date_of_birth',
                'gender',
                'nationality',
                'driving_license',
            ]);
        });
    }
};
