<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('employer_profiles', function (Blueprint $table) {
            $table->id();

            // EMPLOYER

            $table->foreignId('user_id')
                ->constrained()
                ->onDelete('cascade');

            // COMPANY INFO

            $table->string('company_logo')
                ->nullable();

            $table->string('company_name')
                ->nullable();

            $table->string('website')
                ->nullable();

            $table->string('industry')
                ->nullable();

            $table->string('company_size')
                ->nullable();

            $table->string('location')
                ->nullable();

            $table->longText('about')
                ->nullable();

            // SOCIAL LINKS

            $table->string('facebook')
                ->nullable();

            $table->string('linkedin')
                ->nullable();

            $table->string('twitter')
                ->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('employer_profiles');
    }
};
