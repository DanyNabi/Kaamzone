<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('resume_sections', function (Blueprint $table) {
             $table->id();

        $table->foreignId('resume_id')
            ->constrained()
            ->cascadeOnDelete();

        $table->string('section');

        /*
            personal_info
            summary
            experience
            education
            skills
            projects
            certificates
            languages
            references
            awards
            publications
            volunteer
            interests
        */

        $table->integer('sort_order')->default(0);

        $table->boolean('is_visible')->default(true);

        $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('resume_sections');
    }
};
