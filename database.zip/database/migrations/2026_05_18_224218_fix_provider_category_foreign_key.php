<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('provider_category', function (Blueprint $table) {

            // DROP OLD FK

            $table->dropForeign(
                'provider_category_category_id_foreign'
            );

            // ADD NEW FK

            $table->foreign('provider_category_id')
                ->references('id')
                ->on('provider_categories')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('provider_category', function (Blueprint $table) {

            $table->dropForeign([
                'provider_category_id'
            ]);

            $table->foreign('provider_category_id')
                ->references('id')
                ->on('categories')
                ->onDelete('cascade');
        });
    }
};
