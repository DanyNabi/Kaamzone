<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('resume_references', function (Blueprint $table) {
            $table->id();

            $table->foreignId('resume_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('name');

            $table->string('position')->nullable();

            $table->string('company')->nullable();

            $table->string('email')->nullable();

            $table->string('phone')->nullable();

            $table->enum('relationship', [
                'Manager',
                'Supervisor',
                'Colleague',
                'Client',
                'Professor',
                'Other'
            ])->default('Other');

            $table->unsignedInteger('sort_order')
                ->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('resume_references');
    }
};
