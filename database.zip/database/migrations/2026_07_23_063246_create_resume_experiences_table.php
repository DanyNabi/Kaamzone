<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('resume_experiences', function (Blueprint $table) {

            $table->id();

            $table->foreignId('resume_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('job_title');

            $table->string('company');

            $table->string('employment_type')->nullable();
            // Full-time
            // Part-time
            // Contract
            // Internship
            // Freelance

            $table->string('location')->nullable();

            $table->boolean('currently_working')->default(false);

            $table->date('start_date');

            $table->date('end_date')->nullable();

            $table->longText('description')->nullable();

            $table->integer('sort_order')->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('resume_experiences');
    }
};
