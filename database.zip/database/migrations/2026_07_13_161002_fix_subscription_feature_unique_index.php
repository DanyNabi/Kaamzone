<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
         Schema::table('subscription_features', function (Blueprint $table) {

            $table->dropUnique('subscription_features_slug_unique');

            $table->unique(['module_id', 'slug']);

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('subscription_features', function (Blueprint $table) {

            $table->dropUnique(['module_id', 'slug']);

            $table->unique('slug');

        });
    }
};
