<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('hero_sliders', function (Blueprint $table) {
            $table->id();

            // Kis page par show hogi
            $table->string('page');

            // Hero Content
            $table->string('badge')->nullable();

            $table->string('heading');

            $table->text('description')->nullable();

            // Buttons

            $table->string('button1_text')->nullable();
            $table->string('button1_link')->nullable();

            $table->string('button2_text')->nullable();
            $table->string('button2_link')->nullable();

            // Image

            $table->string('image');

            // Display Order

            $table->integer('sort_order')->default(0);

            // Active / Inactive

            $table->boolean('status')->default(1);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('hero_sliders');
    }
};
