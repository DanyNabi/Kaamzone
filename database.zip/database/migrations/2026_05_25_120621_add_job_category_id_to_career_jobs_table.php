<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('career_jobs', function (Blueprint $table) {
            $table->foreignId('job_category_id')
                ->nullable()
                ->after('user_id')
                ->constrained('job_categories')
                ->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('career_jobs', function (Blueprint $table) {
            $table->dropForeign([
                'job_category_id'
            ]);

            $table->dropColumn(
                'job_category_id'
            );
        });
    }
};
