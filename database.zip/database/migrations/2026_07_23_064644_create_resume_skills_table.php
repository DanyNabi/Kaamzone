<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('resume_skills', function (Blueprint $table) {
            $table->id();

            $table->foreignId('resume_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('skill');

            $table->string('category')->nullable();
            // Technical
            // Soft Skill
            // Language
            // Tool
            // Framework

            $table->tinyInteger('level')->default(3);
            // 1 = Beginner
            // 2 = Basic
            // 3 = Intermediate
            // 4 = Advanced
            // 5 = Expert

            $table->integer('sort_order')->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('resume_skills');
    }
};
