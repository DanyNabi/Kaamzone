<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('career_jobs', function (Blueprint $table) {
            $table->id();

            // EMPLOYER

            $table->foreignId('user_id')
                ->constrained()
                ->onDelete('cascade');

            // JOB INFO

            $table->string('title');

            $table->string('slug')
                ->unique();

            $table->string('company_name');

            $table->string('location')
                ->nullable();

            $table->string('job_type')
                ->nullable();

            $table->string('salary')
                ->nullable();

            $table->string('experience')
                ->nullable();

            $table->longText('description');

            $table->string('status')
                ->default('active');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('career_jobs');
    }
};
