<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('resume_languages', function (Blueprint $table) {
            $table->id();

            $table->foreignId('resume_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('language');

            $table->enum('proficiency', [
                'Basic',
                'Conversational',
                'Professional',
                'Native'
            ])->default('Basic');

            $table->unsignedInteger('sort_order')
                ->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('resume_languages');
    }
};
